# ================== Consumo (Y) vs Ingreso (X) ==================
# Lectura (elige consumo.txt)
bd <- read.table(file.choose(), header = TRUE)
bd
stopifnot(all(c("Y","X") %in% names(bd)))#blablabla

bd$Y
bd$X

bd$Y <- as.numeric(bd$Y)
bd$Y

bd$X <- as.numeric(bd$X)
options(na.action = na.exclude)

# Paquetes (instala si faltan)
req <- c("ggplot2","lmtest","sandwich")
for(pk in req) if (!requireNamespace(pk, quietly=TRUE)) install.packages(pk)
library(ggplot2); library(lmtest); library(sandwich)

# -------- OLS ----------
m_ols <- lm(Y ~ X, data = bd)
summary(m_ols)

# Diagnósticos básicos
r <- rstandard(m_ols)
r
par(mfrow=c(1,2))
plot(bd$X, resid(m_ols), xlab="Ingreso (X)", ylab="Residuos", main="Residuos vs X"); abline(h=0,col=2)
qqnorm(r, main="QQ-plot residuos estandarizados"); qqline(r, col=2)
par(mfrow=c(1,1))
shapiro.test(r)
bptest(m_ols)  # Breusch–Pagan (heterocedasticidad)

# EE robustos (HC3) para OLS
coeftest(m_ols, vcov = vcovHC(m_ols, type="HC3"))

# -------- Modelo de varianza: log(e^2) ~ X --------
e  <- resid(m_ols)
bd$log_e2 <- log(e^2 + 1e-8)
m_var <- lm(log_e2 ~ X, data = bd)
summary(m_var)

# Pesos estimados por varianza: omega = exp( - (g0 + g1 X) )
omega_hat <- exp(-predict(m_var, newdata = bd))
summary(omega_hat)

# -------- WLS: (a) pesos = 1/X  y  (b) pesos = omega_hat ----------
m_wls_1x  <- lm(Y ~ X, data = bd, weights = 1/bd$X)
m_wls_hat <- lm(Y ~ X, data = bd, weights = omega_hat)
summary(m_wls_1x)
summary(m_wls_hat)

# -------- Intervalos de predicción (OLS vs WLS_hat) ----------
xg <- data.frame(X = seq(min(bd$X), max(bd$X), length.out = 200))
xg
## OLS (pred. estándar)
pi_ols <- predict(m_ols, newdata = xg, interval = "prediction", level = 0.95)
pi_ols
df_ols <- cbind(xg, fit = pi_ols[,"fit"], lwr = pi_ols[,"lwr"], upr = pi_ols[,"upr"])

## WLS_hat: PI = ajuste +- t * sqrt( var(ajuste) + sigma^2(x) )
X_w   <- model.matrix(m_wls_hat)
W     <- diag(m_wls_hat$weights)
Vb_w  <- solve(t(X_w) %*% W %*% X_w)  # (X'WX)^(-1)

x0    <- model.matrix(~ X, data = xg)
varfit <- rowSums((x0 %*% Vb_w) * x0)
sigma2_x0 <- exp(predict(m_var, newdata = xg))  # varianza cond. estimada

se_pred_w <- sqrt(varfit + sigma2_x0)
tcrit_w   <- qt(0.975, df = m_wls_hat$df.residual)

fit_w <- predict(m_wls_hat, newdata = xg)
df_w  <- cbind(xg,
               fit = fit_w,
               lwr = fit_w - tcrit_w*se_pred_w,
               upr = fit_w + tcrit_w*se_pred_w)
df_w
# -------- Gráfico comparativo ----------
ggplot() +
  geom_point(data = bd, aes(X, Y), alpha = 0.8) +
  # OLS
  geom_ribbon(data = df_ols, aes(X, ymin=lwr, ymax=upr), alpha = 0.15) +
  geom_line(data = df_ols, aes(X, y=fit), linewidth=1, linetype=2) +
  # WLS (omega_hat)
  geom_ribbon(data = df_w, aes(X, ymin=lwr, ymax=upr), alpha = 0.15) +
  geom_line(data = df_w, aes(X, y=fit), linewidth=1) +
  labs(x="Ingreso (X)", y="Consumo (Y)",
       title="Predicción e intervalos: OLS (----) vs WLS (—)",
       subtitle="WLS con pesos derivados de log(e^2) ~ X") +
  theme_minimal()

# -------- ¿Mejoraron las predicciones? (CV K=5, escala Y) ----------
set.seed(1)
K <- 5
fold <- sample(rep(1:K, length.out=nrow(bd)))
rmse <- function(y,yh) sqrt(mean((y-yh)^2))
mae  <- function(y,yh) mean(abs(y-yh))

cv_ols <- lapply(1:K, function(k){
  tr <- bd[fold!=k,]; te <- bd[fold==k,]
  fit <- lm(Y ~ X, data=tr)
  pred <- predict(fit, newdata=te)
  c(RMSE=rmse(te$Y,pred), MAE=mae(te$Y,pred))
})
cv_wls <- lapply(1:K, function(k){
  tr <- bd[fold!=k,]; te <- bd[fold==k,]
  fit1 <- lm(Y ~ X, data=tr)
  tr$log_e2 <- log(resid(fit1)^2 + 1e-8)
  mvar_tr <- lm(log_e2 ~ X, data=tr)
  w_tr <- exp(-predict(mvar_tr, newdata=tr))
  fit2 <- lm(Y ~ X, data=tr, weights=w_tr)
  pred <- predict(fit2, newdata=te)
  c(RMSE=rmse(te$Y,pred), MAE=mae(te$Y,pred))
})
apply(do.call(rbind, cv_ols), 2, mean)
apply(do.call(rbind, cv_wls), 2, mean)
