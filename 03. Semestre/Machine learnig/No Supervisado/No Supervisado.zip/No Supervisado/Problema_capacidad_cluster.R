rm(list = ls())


library(ompr)
library(ompr.roi)
library(ROI)
library(ROI.plugin.glpk)

x <- c(1, 4, 9)
n <- length(x)
k <- 2
capacity <- c(2, 2)

M <- 100  # suficientemente grande

model <- MIPModel() %>%
  
  # variables
  add_variable(z[i, h], i = 1:n, h = 1:k, type = "binary") %>%
  add_variable(mu[h], h = 1:k, type = "continuous") %>%
  add_variable(d[i, h], i = 1:n, h = 1:k, lb = 0) %>%
  add_variable(w[i, h], i = 1:n, h = 1:k, lb = 0) %>%
  
  # asignación única
  add_constraint(sum_expr(z[i, h], h = 1:k) == 1, i = 1:n) %>%
  
  # capacidad
  add_constraint(sum_expr(z[i, h], i = 1:n) <= capacity[h], h = 1:k) %>%
  
  # distancia absoluta
  add_constraint(d[i, h] >= x[i] - mu[h], i = 1:n, h = 1:k) %>%
  add_constraint(d[i, h] >= mu[h] - x[i], i = 1:n, h = 1:k) %>%
  
  # linealización w = z * d
  add_constraint(w[i, h] <= M * z[i, h], i = 1:n, h = 1:k) %>%
  add_constraint(w[i, h] <= d[i, h], i = 1:n, h = 1:k) %>%
  add_constraint(w[i, h] >= d[i, h] - M * (1 - z[i, h]), i = 1:n, h = 1:k) %>%
  
  # objetivo
  set_objective(sum_expr(w[i, h], i = 1:n, h = 1:k), "min")

solution <- solve_model(model, with_ROI(solver = "glpk"))

solution$status
get_solution(solution, z[i, h])
get_solution(solution, mu[h])
