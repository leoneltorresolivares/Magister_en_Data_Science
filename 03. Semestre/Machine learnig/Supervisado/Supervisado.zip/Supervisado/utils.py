#!/usr/bin/env python3
"""
Shared data-loading, feature-engineering and reporting helpers for the
custodial-sentence regression models on the Chilean Judiciary "Sentencias, Penas
y Beneficios" dataset.

Used by regresion_condena.py (plain LinearRegression), ridge_condena.py and
lasso_condena.py (RandomizedSearchCV over the regularization strength). The model
is the only thing those scripts differ in; everything else lives here.

Target (y):  log1p(total days of imprisonment),  days = AÑOS*365 + MESES*30 + DIAS
Features (X):
    - EDAD CONDENADO                      (numeric, cubic spline)
    - SEXO CONDENADO                      (categorical)
    - CÓDIGO DELITO × PROCEDIMIENTO       (engineered crossed categorical)
    - CÓDIGO CORTE, CÓDIGO TRIBUNAL SENTENCIA  (court fixed effects)

Only condemnatory rows (RESULTADO SENTENCIA == "Condenado") with a recorded
custodial penalty are used. See CLAUDE.md / Ficha_Tecnica_Sentencias.pdf for the
data caveats this relies on (penalty split across AÑOS/MESES/DIAS, optional
sex/age fields, participant-x-delito grain, etc.).
"""
from __future__ import annotations

import argparse
import glob
import sys

import numpy as np
import pandas as pd
from scipy.stats import loguniform, randint
from sklearn.compose import ColumnTransformer
from sklearn.metrics import (
    mean_absolute_error,
    mean_pinball_loss,
    mean_squared_error,
    r2_score,
)
from sklearn.model_selection import RandomizedSearchCV, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, SplineTransformer, TargetEncoder

SHEET_NAME = "Sentencias Penas Beneficios"

# Exact column headers as they appear in the workbooks.
COL_AGE = "EDAD CONDENADO"
COL_SEX = "SEXO CONDENADO"
COL_DELITO = "CÓDIGO DELITO"
COL_RESULT = "RESULTADO SENTENCIA"
COL_YEARS = "AÑOS"
COL_MONTHS = "MESES"
COL_DAYS = "DIAS"
COL_PROC = "PROCEDIMIENTO"
COL_CORTE = "CÓDIGO CORTE"
COL_TRIB = "CÓDIGO TRIBUNAL SENTENCIA"
COL_DELITO_PROC = "DELITO_PROC"  # engineered CÓDIGO DELITO × PROCEDIMIENTO interaction

DEFAULT_FILES = ["data/Sentencias Penas Beneficios 2024.xlsx"]


def load(paths: list[str]) -> pd.DataFrame:
    """Read and concatenate the relevant columns from one or more yearly files."""
    usecols = [COL_AGE, COL_SEX, COL_DELITO, COL_RESULT, COL_YEARS, COL_MONTHS, COL_DAYS,
               COL_PROC, COL_CORTE, COL_TRIB]
    frames = []
    for path in paths:
        print(f"  reading {path} ...", flush=True)
        df = pd.read_excel(path, sheet_name=SHEET_NAME, usecols=usecols)
        frames.append(df)
    return pd.concat(frames, ignore_index=True)


def build_dataset(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    """Filter to condemnatory rows and build the X / y matrices."""
    # Keep only condemnatory results ("Condenado").
    df = df[df[COL_RESULT].astype(str).str.strip().str.lower() == "condenado"].copy()

    # Penalty components -> numeric (anything non-numeric becomes 0).
    for col in (COL_YEARS, COL_MONTHS, COL_DAYS):
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    # Target: total custodial days.
    y = df[COL_YEARS] * 365 + df[COL_MONTHS] * 30 + df[COL_DAYS]

    # Age must be numeric; sex/delito kept as strings (optional fields).
    df[COL_AGE] = pd.to_numeric(df[COL_AGE], errors="coerce")
    df[COL_SEX] = df[COL_SEX].astype(str).str.strip().str.lower()
    for c in (COL_DELITO, COL_PROC, COL_CORTE, COL_TRIB):
        df[c] = df[c].astype(str).str.strip()

    # Explicit DELITO × PROCEDIMIENTO interaction: lets each crime's expected
    # sentence shift by procedure type (Abreviado / Simplificado / Ordinario),
    # which carries most of the lift over a purely additive model.
    df[COL_DELITO_PROC] = df[COL_DELITO] + "|" + df[COL_PROC]

    X = df[[COL_AGE, COL_SEX, COL_DELITO_PROC, COL_CORTE, COL_TRIB]]

    # Drop rows with no usable age, no penalty, or implausible age.
    mask = (
        X[COL_AGE].notna()
        & X[COL_AGE].between(10, 100)
        & (y > 0)
        & (y < 365 * 100)  # filter out extreme outliers (e.g. life sentences coded as 9999 years)
        & (df[COL_SEX] != "nan")
    )
    return X[mask], np.log1p(y[mask])


def build_model(model) -> Pipeline:
    """Wrap an sklearn estimator in the shared preprocessing pipeline."""
    pre = ColumnTransformer(
        transformers=[
            # Age has a weak, non-linear relationship with sentence length; a cubic
            # spline captures it better than a single scaled term.
            ("age", SplineTransformer(n_knots=5, degree=3), [COL_AGE]),
            ("sex", OneHotEncoder(handle_unknown="ignore"), [COL_SEX]),
            # Crossed delito×procedimiento, court and tribunal are all high-cardinality;
            # OneHot stays sparse and unknown levels at predict time are ignored.
            ("delito_proc", OneHotEncoder(handle_unknown="ignore"), [COL_DELITO_PROC]),
            ("corte", OneHotEncoder(handle_unknown="ignore"), [COL_CORTE]),
            ("tribunal", OneHotEncoder(handle_unknown="ignore"), [COL_TRIB]),
        ]
    )
    # No PolynomialFeatures: on one-hot inputs degree-2 mostly produced zeros while
    # exploding the design matrix. The DELITO_PROC cross is the interaction that matters.
    return Pipeline([("pre", pre), ("reg", model)])


# Categoricals that are too high-cardinality to one-hot for a tree model
# (DELITO_PROC alone has thousands of levels).
HIGH_CARD_COLS = [COL_DELITO_PROC, COL_CORTE, COL_TRIB]


def build_tree_model(model) -> Pipeline:
    """Wrap a tree estimator (HistGradientBoosting) in tree-appropriate preprocessing.

    Differs from build_model on purpose: one-hot would explode DELITO_PROC into
    thousands of sparse columns that trees split poorly, and trees model age's
    non-linearity directly so no spline is needed. Instead the high-cardinality
    categoricals are target-encoded into dense numeric columns and age passes
    through raw. TargetEncoder cross-fits internally, so it is leakage-safe when
    nested inside RandomizedSearchCV's CV folds.
    """
    pre = ColumnTransformer(
        transformers=[
            # Age has a weak, non-linear relationship with sentence length; a cubic
            # spline captures it better than a single scaled term.
            ("age", SplineTransformer(n_knots=5, degree=3), [COL_AGE]),
            ("sex", OneHotEncoder(handle_unknown="ignore"), [COL_SEX]),
            # Crossed delito×procedimiento, court and tribunal are all high-cardinality;
            # OneHot stays sparse and unknown levels at predict time are ignored.
            ("delito_proc", OneHotEncoder(handle_unknown="ignore"), [COL_DELITO_PROC]),
            ("corte", OneHotEncoder(handle_unknown="ignore"), [COL_CORTE]),
            ("tribunal", OneHotEncoder(handle_unknown="ignore"), [COL_TRIB]),
        ],
        remainder="passthrough",  # EDAD CONDENADO passes through raw
        # HistGradientBoosting rejects sparse input; force the one-hot blocks dense.
        sparse_threshold=0.0,
    )
    return Pipeline([("pre", pre), ("reg", model)])


def report(model: Pipeline, X_test, y_test, quantile: float | None = None) -> None:
    """Print held-out performance, with metrics back-transformed to real days.

    Pass `quantile` for a quantile-loss model to also print the pinball loss (the
    metric it actually optimizes) and the empirical coverage.
    """
    # The model is trained on log1p(days); back-transform predictions and the
    # held-out target to real days so every metric below is in actual days.
    pred = np.expm1(model.predict(X_test))
    true = np.expm1(y_test)
    rmse = np.sqrt(mean_squared_error(true, pred))
    print("\n=== Test-set performance (target = total days of condena) ===")
    print(f"  n_test : {len(y_test):,}")
    print(f"  R^2    : {r2_score(true, pred):.4f}  (on real days)")
    print(f"  MAE    : {mean_absolute_error(true, pred):,.1f} days")
    print(f"  RMSE   : {rmse:,.1f} days")

    if quantile is not None:
        # Pinball loss is the metric a quantile model optimizes; R^2/RMSE assume a
        # conditional-mean fit and understate it. Coverage = share of true values at
        # or below the prediction; for a calibrated quantile it should sit near q.
        pinball = mean_pinball_loss(true, pred, alpha=quantile)
        coverage = float(np.mean(true <= pred))
        print(f"  pinball: {pinball:,.1f} days  (alpha={quantile:g})")
        print(f"  coverage: {coverage:.3f}  (target {quantile:g})")

    reg = model.named_steps["reg"]
    # Tree ensembles have no single intercept; only linear models expose one.
    if hasattr(reg, "intercept_"):
        print(f"\n  intercept (log1p-days space): {reg.intercept_:.3f}")


# RandomizedSearchCV over the regularization strength, shared by Ridge/Lasso.
ALPHA_PARAM_DIST = {"reg__alpha": loguniform(1e-3, 1e3)}


def buscar_mejor_alpha(modelo, n_iter: int = 10, cv: int = 10, seed: int = 42) -> RandomizedSearchCV:
    """RandomizedSearchCV over the pipeline's reg__alpha; returns the (unfitted) search."""
    return RandomizedSearchCV(
        estimator=build_model(modelo),
        param_distributions=ALPHA_PARAM_DIST,
        n_iter=n_iter,
        cv=cv,
        scoring="r2",
        random_state=seed,
        n_jobs=-1,
    )


# Search space for HistGradientBoostingRegressor (used by hgb_condena.py). Keys are
# prefixed `reg__` to address the estimator step inside the build_tree_model pipeline.
HGB_PARAM_DIST = {
    "reg__learning_rate": loguniform(1e-2, 3e-1),
    "reg__max_iter": randint(200, 800),
    "reg__max_leaf_nodes": randint(15, 63),
    "reg__max_depth": [None, 4, 6, 10],
    "reg__min_samples_leaf": randint(20, 200),
    "reg__l2_regularization": loguniform(1e-3, 1e1),
}


def buscar_hiperparametros(
    pipeline: Pipeline, param_dist: dict, scoring, n_iter: int = 20, cv: int = 5, seed: int = 42
) -> RandomizedSearchCV:
    """Generic RandomizedSearchCV over an already-built pipeline; returns it unfitted.

    Unlike buscar_mejor_alpha this takes the pipeline and scoring explicitly, so a
    quantile model can be tuned on the pinball loss instead of R^2.
    """
    return RandomizedSearchCV(
        estimator=pipeline,
        param_distributions=param_dist,
        n_iter=n_iter,
        cv=cv,
        scoring=scoring,
        random_state=seed,
        n_jobs=-1,
    )


def parse_args(doc: str | None = None, add_hgb_args: bool = False) -> argparse.Namespace:
    """Standard CLI: positional xlsx globs plus --test-size / --seed.

    With add_hgb_args=True, also exposes --quantile / --n-iter / --cv for the
    quantile-loss gradient-boosting script.
    """
    parser = argparse.ArgumentParser(description=doc, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("files", nargs="*", help="xlsx file(s); supports globs")
    parser.add_argument("--test-size", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=42)
    if add_hgb_args:
        parser.add_argument("--quantile", type=float, default=0.5,
                            help="target quantile for the quantile loss (0<q<1; 0.5 = median)")
        parser.add_argument("--n-iter", type=int, default=20,
                            help="RandomizedSearchCV parameter samples")
        parser.add_argument("--cv", type=int, default=5,
                            help="cross-validation folds for the hyper-parameter search")
    return parser.parse_args()


def load_split(args: argparse.Namespace):
    """Resolve input globs, load, build the dataset, print a summary, and split.

    Returns (X_train, X_test, y_train, y_test). Exits(1) if no input files match.
    """
    patterns = args.files or DEFAULT_FILES
    paths: list[str] = []
    for p in patterns:
        paths.extend(sorted(glob.glob(p)) or [p])
    paths = [p for p in paths if not p.startswith("~$")]
    if not paths:
        print("No input files found.", file=sys.stderr)
        raise SystemExit(1)

    print(f"Loading {len(paths)} file(s)...")
    raw = load(paths)
    print(f"  raw rows: {len(raw):,}")

    X, y = build_dataset(raw)
    print(f"  usable condemnatory rows: {len(X):,}")
    print(f"  target days  -> mean {y.mean():,.0f}  median {y.median():,.0f}  max {y.max():,.0f}")
    print(f"  distinct DELITO×PROC levels: {X[COL_DELITO_PROC].nunique():,}")

    return train_test_split(X, y, test_size=args.test_size, random_state=args.seed)
