# actividad práctica GLM

tiempo <- c(3.03, 5.53, 5.60, 9.30, 9.92, 12.51, 12.95, 15.21, 16.04, 16.84,
            3.19, 4.26, 4.47, 4.53, 4.67, 4.69, 5.78, 6.79, 9.37, 12.75, 
            3.46, 5.22, 5.69, 6.54, 9.16, 9.40, 10.19, 10.71, 12.58, 13.41,
            5.88, 6.74, 6.90, 6.98, 7.21, 8.14, 8.59, 9.80, 12.28, 25.46, 
            6.43, 9.97, 10.39, 13.55, 14.45, 14.72, 16.81, 18.39, 20.84, 21.51)

motores  <- factor(rep(c(1,2,3,4,5), each=10)) #creando un factordatos    <- factor(motores, labels=c("tipo 1", "tipo 2", "tipo 3", "tipo 4", "tipo 5"))
            
# Exploración

library(paletteer)


boxplot(tiempo ~ motores, horizontal = F, col = paletteer_c("ggthemes::Blue-Teal", 5), cex=0.9)


plot(density(tiempo), col = "gray", main = "Grafico de desidad", cex.lab = 1.2, lwd = 2)
rug(jitter(tiempo))


# Gaussiana


modelo_gaus = glm(tiempo ~ motores, family = gaussian())
summary(modelo_gaus)
anova(modelo_gaus, test = "F") # Analisis de desvio, Chisq cuando es binomial o poisson


library(hnp)


hnp(modelo_gaus, resid.type = "deviance") # análisis de residuos, deben estar cerca de la lineacerca de la linea


library(nortest)


lillie.test(resid(modelo_gaus, type = "deviance")) # Test de normalidad, if valor p menor a sig, rechazar h0


# Deberian estar entre -2 y 2, mal comportamiento de los residuos
plot(fitted(modelo_gaus), resid(modelo_gaus, type="deviance"), xlab="valores ajustados", ylab="Resíduos componente de desvío", ylim=c(-3,3))
lines(loess.smooth(fitted(modelo_gaus), resid(modelo_gaus, type="deviance")))
abline(h=0, lty=2)

# No hay valores cuya existencia afecte el modelo (olvide el termino) menor a 0.4
plot(cooks.distance(modelo_gaus), type = "h", lwd = 2, col = "blue", ylim=c(0,1))


# gamma con enlace logaritmica
modelo_gamma = glm(tiempo ~ motores, family = Gamma(link = log))
summary(modelo_gamma)
anova(modelo_gamma, test = "F") # Analisis de desvio, Chisq cuando es binomial o poisson


hnp(modelo_gamma, resid.type = "deviance") # análisis de residuos, deben estar cerca de la lineacerca de la linea


lillie.test(resid(modelo_gamma, type = "deviance")) # Test de normalidad, if valor p menor a sig, rechazar h0


# Deberian estar entre -2 y 2, mal comportamiento de los residuos
plot(fitted(modelo_gamma), resid(modelo_gamma, type="deviance"), xlab="valores ajustados", ylab="Resíduos componente de desvío", ylim=c(-3,3))
lines(loess.smooth(fitted(modelo_gamma), resid(modelo_gamma, type="deviance")))
abline(h=0, lty=2)

# No hay valores cuya existencia afecte el modelo (olvide el termino) menor a 0.4
plot(cooks.distance(modelo_gamma), type = "h", lwd = 2, col = "blue", ylim=c(0,1))


# Gana gamma
AIC(modelo_gaus)
AIC(modelo_gamma)
















            