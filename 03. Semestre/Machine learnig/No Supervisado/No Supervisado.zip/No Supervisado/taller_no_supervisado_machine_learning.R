# taller no supervisado machine learning

############################
# deadline, 1 de junio 
############################


rm(list = ls())


ruta = "C:/Users/Leo Tactics/OneDrive/Escritorio/Magister en Data Science/Semestre 3/Machine learning"
ruta = "C:/Users/19990772/Desktop/Mg Data Science/03. semestre/Machine Learning"

setwd(ruta)

library(readr)
library(tidyr)
library(dplyr)
library(proxy)
library(dtw)
library(dtwclust)
library(doParallel)


datos = tibble(read_delim("DatosTaller.csv", 
                       delim = ";", escape_double = FALSE, trim_ws = TRUE))


# Pregunta 1: Alineación Temporal Dinámica (DTW) en Firmas Espectrales ----------

str(datos)
head(datos) # estan como character los caracter

# dejar el target fuera

y = datos$rec_mass_10_pt


# resto de predictores


x = datos[,-1]

# pasar a numeric

x = x %>% mutate(across(everything(), ~ as.numeric(gsub(",", ".", .))))
str(x[,2100:ncol(x)])

# para efecto de visualización posteriores
x$id = 1:nrow(x)

df_largo = pivot_longer(
  x, cols = -id, names_to = "longitud de onda", values_to = "absorbancia"
)

df_largo$`longitud de onda` = as.numeric(df_largo$`longitud de onda`)


# normalizar

x_escalado = scale(x)
x_escalado = as.matrix(x_escalado)

# Versión super rebuscada 

# Paralelización
cl = makeCluster(11)
registerDoParallel(cl)

# Cálculo DTW (opción recomendada en rpubs)
system.time({
  dist_dtw = proxy::dist(
    split(x_escalado, row(x_escalado)),  # convierte a lista de vectores fila
    method      = "dtw_basic",
    window.size = 20,
    norm        = "L2"
  )
})

stopCluster(cl)

# Guardar altiro
saveRDS(dist_dtw, "dist_dtw_resultado.rds")


class(dist_dtw)


summary(dist_dtw)


matrix_dtw = as.matrix(dist_dtw)
dim(matrix_dtw)


# mania de guardar en excel
library(openxlsx)
#write.xlsx(matrix_dtw, "resulatdos_matriz_dtw.xlsx")


# Pregunta 2 Uso de algoritmo k-medoids ---------


library(cluster)
library(readxl)

# cargar data en cado de borrar memoria
df = tibble(read_excel("resulatdos_matriz_dtw.xlsx"))
str(df)

# vector vacio para la siuluette
siluete = c()


# buscar k optimo
for (k in 2:10){
  pam_tec = pam(df, k = k, diss = T) # diss le indica a pam que df ya es una matriz de disimilitud (realizado en el item 1)
  siluete[k] = pam_tec$silinfo$avg.width
}


siluete


df_sil = data.frame(k = 2:10, silhouette = siluete[2:10])

ggplot(df_sil, aes(x = k, y = silhouette)) +
  geom_line(linewidth = 1) +
  geom_point(size = 3) +
  geom_vline(
    xintercept = df_sil$k[
      which.max(df_sil$silhouette)
    ],
    linetype = "dashed",
    linewidth = 0.8
  ) +
  geom_text(aes(label = round(silhouette, 3)),
    vjust = -0.8,
    size = 4
  ) +
  theme_minimal(base_size = 14) +
  labs(
    title = "Selección del número óptimo de clusters",
    subtitle = "Análisis mediante coeficiente promedio de Silhouette",
    x = "Número de clusters (k)",
    y = "Silhouette promedio"
  ) +
  scale_x_continuous(
    breaks = 2:10
  ) +
  theme(
    plot.title = element_text(
      face = "bold"
    ),
    axis.title = element_text(
      face = "bold"
    ),
    panel.grid.minor = element_blank()
  )


# usar k optimo (8)

k_optimo = 8

pam_final = pam(df, k = k_optimo, diss = T)


pam_final$clusinfo
pam_final$medoids # equivalente a los centroides, con la diferencia que es una obs real
pam_final$clustering


df_largo$PAM = pam_final$clustering[df_largo$id]

ggplot(df_largo,
  aes(x = `longitud de onda`,y = absorbancia,
    group = id,
    color = as.factor(PAM)
  )
) +
  geom_line(alpha = 0.15) +
  theme_minimal() +
  labs(
    title = "Firmas espectrales agrupadas mediante PAM",
    color = "Cluster"
  )+
  theme(
    legend.title = element_text(size = 9),
    legend.text = element_text(size = 7)
  ) +
  guides(
    color = guide_legend(
      override.aes = list(
        alpha = 1,
        linewidth = 2
      )
    )
  )


# Pregunta 3 restricción de clusters -------
# Mismo caso que la pregunta 2 pero con restriccion de tamaño de clusters

# Nos quedamos con el caso de k = 8 ya que tiene el mejor valor en metrica siluette y cumple con la restricción de capacidad

for(k in 8:20){
  
  pam_cap <- pam(
    df,
    k = k,
    diss = TRUE
  )
  
  print(pam_cap$clusinfo[, "size"])
  
  if(all(pam_cap$clusinfo[, "size"] <= 300)){
    
    print(paste("k válido:", k))
    
    break
  }
}

# Pregunta 4. Uso del algoritmo HDBSCAN ---------------

library(dbscan)


minPts = c(5, 10, 15, 20, 25)

resultados = data.frame()

for(i in minPts){
  
  hdb = hdbscan(
    df, minPts = i
  )
  
  n_clusters = length(unique(hdb$cluster[hdb$cluster != 0]))
  
  n_ruido = sum(hdb$cluster == 0)
  
  va = data.frame(minPts = i, clusters = n_clusters, ruido = n_ruido)
  
  resultados = rbind(resultados, va)
  
}


resultados

# usamos minPts = 10 para no ser tan permisivos o restrictivos
hdb = hdbscan(
  as.matrix(df),
  minPts = 10
)

hdb$cluster
sum(hdb$cluster == 0)

df_largo$HDB = hdb$cluster[df_largo$id]

ggplot(df_largo,
       aes(x = `longitud de onda`,y = absorbancia,
           group = id,
           color = as.factor(HDB)
       )
) +
  geom_line(alpha = 0.15) +
  theme_minimal() +
  labs(
    title = "Firmas espectrales agrupadas mediante HDB",
    color = "Cluster"
  )+
  theme(
    # quizas bajar un poco la leyenda
    legend.title = element_text(size = 9),
    legend.text = element_text(size = 7)
  ) +
  guides(
    color = guide_legend(
      override.aes = list(
        alpha = 1,
        linewidth = 2
      )
    )
  )


# Pregunta 5. Regresión PLS ----------


# datos en train y test


set.seed(1234)


train_id = sample(1:nrow(x_escalado), size = 0.7 * nrow(x_escalado))


x_train = x_escalado[train_id, ]
x_test = x_escalado[-train_id, ]

y_train = y[train_id]
y_test = y[-train_id]


library(pls)


# modelo inicial


pls_fit = plsr(y_train ~ x_train, ncomp = 30, validation = "CV")


rmsep_obj = pls::RMSEP(pls_fit)
rmsep_vec = as.numeric(rmsep_obj$val[1, 1, ])

tabla_rmsep = data.frame(
  componentes = 0:(length(rmsep_vec) - 1),
  RMSEP = rmsep_vec
)

tabla_rmsep_sin_0 = tabla_rmsep %>%
  filter(componentes >= 1)

opt_comp = tabla_rmsep_sin_0$componentes[
  which.min(tabla_rmsep_sin_0$RMSEP)
]


# ver RMSE
validationplot(pls_fit, val.type = "RMSEP")


ggplot(
  tabla_rmsep_sin_0,
  aes(x = componentes, y = RMSEP)
) +
  geom_line() +
  geom_point(size = 2) +
  geom_vline(xintercept = opt_comp, linetype = "dashed") +
  theme_minimal() +
  labs(
    title = "Selección de componentes PLS",
    x = "Número de componentes",
    y = "RMSEP"
  )


# rcuadrado
validationplot(pls_fit, val.type = "R2")


pred_test = predict(pls_fit, newdata = x_test, ncomp = opt_comp)


rmse_test = sqrt(mean((y_test - pred_test)^2))


r2_test = cor(y_test, pred_test)^2


df_pred = data.frame(observado = y_test, predicho = as.vector(pred_test))


ggplot(df_pred, aes(x = observado, y = predicho)) +
  geom_point(alpha = 0.6) +
  geom_abline(
    slope = 1,
    intercept = 0,
    linetype = "dashed",
    color = "red"
  ) +
  theme_minimal() +
  labs(
    title = "Valores observados vs predichos",
    x = "Recuperación observada",
    y = "Recuperación predicha"
  )


# Pregunta 6. Scores y diferencia entre grupos ------------


scores_opt = pls_fit$scores[,1:opt_comp]


scores_pls = as.data.frame(scores_opt)


#scores_pls$id <- x$id
#scores_pls$y <- df$y


set.seed(1234)


sil_scores = c()


for(k in 2:20){
  
  km = kmeans(scores_pls, centers = k, nstart = 25)
  
  sil = silhouette(km$cluster, dist(scores_pls))
  
  sil_scores[k] = mean(sil[,3])
}


tabla_sil = data.frame(k = 2:20, silhouette = sil_scores[2:20])


ggplot(tabla_sil, aes(x = k, y = silhouette))+
  geom_line() +
  geom_point(size = 2) +
  theme_minimal() +
  labs(
    title = "Selección de k mediante Silhouette",
    x = "Número de clusters",
    y = "Silhouette promedio"
  )


k_optimo = tabla_sil$k[which.max(tabla_sil$silhouette)]


km = kmeans(scores_pls, centers = k_optimo, nstart = 25)


df_scores = data.frame(scores_pls, cluster = as.factor(km$cluster), recuperacion = y_train)


ggplot(df_scores, aes(x = cluster, y = recuperacion, fill = cluster)) +
  geom_boxplot(alpha = 0.75) +
  geom_jitter(width = 0.12, alpha = 0.55, size = 1.8) +
  theme_minimal() +
  guides(fill = "none") +
  labs(
    title = "Grupos",
    x = "Cluster",
    y = "Recuperación"
  )


anova_res = aov(recuperacion ~ cluster, data = df_scores)

summary(anova_res)


# Pregunta 7. Reglas de asociación ---------


# PYTHON









