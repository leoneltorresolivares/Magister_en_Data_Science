rm(list = ls())


ruta = "C:/Users/19990772/Desktop/Mg Data Science/Segundo semestre/Modelos Lineales/Profe Jose/codigos_modelos"


library(ggplot2)
library(dplyr)
library(scales)
library(MASS)
library(gridExtra) #Grilla para varios gráficos en uno
library(Metrics) # Metricas


df <- read.table(file.choose(), header = TRUE)


str(df)


#Y dependiente
#X independiente

# 1 Ajuste el modelo lineal Y ~ X


modelo = lm(Y~X, data = df)
summary(modelo)


# 2 Realice un análisis gráfico de los supuestos de un modelo lineal. ¿Se cumplen?


e = resid(modelo) #residuos estandar
g1 = ggplot(df, aes(x = X, y = e)) +
  geom_point() +
  geom_hline(yintercept = 0, color = "red") +
  labs(title = "Residuos estandar")+
  theme_minimal()


r = ls.diag(modelo)$std.res #residuos normalizados
g2 = ggplot(df, aes(x = X, y = r)) +
  geom_point() +
  geom_hline(yintercept = 0, color = "red") +
  labs(title = "Residuos normalizados")+
  theme_minimal()


grid.arrange(g1, g2, ncol = 2)


# 3 Si no se cumple la homocedasticidad, analice la dependencia de los residuos con la variable predictora


qqnorm(r)
qqline(r)
ks.test(r,pnorm)
shapiro.test(r) #no se rechaza h0, se asume normalidad


# 4 Ajuste el modelo lineal considerando ahora como variable respuesta log (ˆϵ2).


loge = log(e^2)

new_modelo = lm(loge ~ X, data = df)
summary(new_modelo)


# 5 A partir del modelo anterior, defina los pesos ω.

hat = predict(new_modelo, newdata = model.frame(modelo))

var_hat = exp(hat)

weights = 1/var_hat

weights = weights / mean(weights)


# 6 Ajuste nuevamente el modelo lineal. ¿Mejoraron las predicciones?


modelo_weights <- lm(formula(modelo), data = model.frame(modelo), weights = weights)
summary(modelo_weights)
e_weights = resid(modelo_weights)


y_real = df$Y
y_pred_ols = fitted(modelo)
y_pred_w = fitted(modelo_weights)


rmse_ols = rmse(y_real, y_pred_ols)
rmse_w = rmse(y_real, y_pred_w)
rmse_ols
rmse_w


mae_ols = mae(y_real, y_pred_ols)
mae_w = mae(y_real, y_pred_w)
mae_ols
mae_w

r2_ols  <- summary(modelo)$adj.r.squared
r2_w  <- summary(modelo_weights)$adj.r.squared
r2_ols
r2_w


# 7 Determine los intervalos de prediccion de los 2 modelos. Grafique las predicciones.






