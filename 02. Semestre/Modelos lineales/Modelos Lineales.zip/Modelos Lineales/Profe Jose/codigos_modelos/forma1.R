bd<-file.choose()
bd <- read.table(file.choose(), header = TRUE)
head(bd)
attach(bd)


#Y consumo
#X Ingreso

#Ajuste el modelo lineal Y ∼ X.

modelo<-lm(Y~X)
summary(modelo)


#2. Realice un analisis grfico de los supuestos de un modelo lineal.
#Se cumplen?

#linealidad de la media
par(mfrow=c(1,1))
e<-resid(modelo)
plot(X,e)
abline(h=0,col="red")

#Existe una nube de puntos entono al cero

#homocedasticidad

r=ls.diag(modelo)$std.res

plot(X,r)
abline(h=0,col="red")

#Las amplitud de los residuos es distintos lo que no sustenta el principio
#de homocedasticidad
#La amplitud crece a medida que crece el predictor

#Normalidad

qqnorm(r)
qqline(r)
ks.test(r,pnorm)
#No rechaza normalidad, aunque existe observaciones en los extremos
#que se alejan de la regresion lineal


Z<-Y/sqrt(X)
V1<-1/sqrt(X)
V2<-sqrt(X)
modelo<-lm(Z~V1+V2-1)


r=ls.diag(modelo)$std.res
plot(fitted(modelo),r, xlab="valores ajustados",ylab="residuos estandarizados",main="Modelo con la primera transformación")


Z<-Y/X
V2<-1/X
v1<-X
modelo<-lm(Z~V2+v1-1)
r=ls.diag(modelo)$std.res
plot(fitted(modelo),r, xlab="valores ajustados",ylab="residuos estandarizados",main="Modelo de la segunda transformación")


#Estimar los minimos cuadrados ponderados utilizando la matriz de pesos
n<-length(X)
x<-cbind(rep(1,n),X) ##la matriz x la puse en minuscula por que y estaba utilizando la mayuscula
omega<-1/sqrt(X)
W<-diag(omega)
y<-matrix(Y,nrow=n)

beta.gorro<-solve(t(x)%*%W%*%x)%*%t(x)%*%W%*%y
modelo.mcp<-lm(Y~X,weights=1/sqrt(X))
summary(modelo.mcp)

modelo.mcp<-lm(Y~X,weights=1/X)
summary(modelo.mcp)
