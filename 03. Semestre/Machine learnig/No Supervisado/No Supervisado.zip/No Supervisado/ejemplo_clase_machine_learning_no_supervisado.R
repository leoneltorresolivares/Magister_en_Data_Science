# ============================================================
# PLS + CLUSTERING CON DATOS NIR REALES
# Dataset: gasoline del paquete pls
# ============================================================

rm(list = ls())

# ------------------------------------------------------------
# 0. Paquetes
# ------------------------------------------------------------

paquetes <- c("pls", "ggplot2", "dplyr", "tidyr", "cluster")

for (pkg in paquetes) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg)
  }
}

library(pls)
library(ggplot2)
library(dplyr)
library(tidyr)
library(cluster)

set.seed(123)

# ------------------------------------------------------------
# 1. Cargar datos
# ------------------------------------------------------------

data(gasoline, package = "pls")

X <- gasoline$NIR
X <- unclass(X)
X <- as.matrix(X)

y <- as.numeric(gasoline$octane)

n <- nrow(X)
p <- ncol(X)

x_names <- paste0("x", seq_len(p))
colnames(X) <- x_names

wl <- seq(900, 1700, length.out = p)

spectra_df <- as.data.frame(X, check.names = FALSE)
names(spectra_df) <- x_names

df <- data.frame(
  id = seq_len(n),
  y = y,
  spectra_df,
  check.names = FALSE
)

cat("Muestras:", n, "\n")
cat("Variables NIR:", p, "\n")
cat("Primeros nombres de df:\n")
print(head(names(df), 10))

# ------------------------------------------------------------
# 2. Espectros en formato largo
# ------------------------------------------------------------

df_long <- df %>%
  dplyr::select(id, dplyr::all_of(x_names)) %>%
  tidyr::pivot_longer(
    cols = dplyr::all_of(x_names),
    names_to = "variable",
    values_to = "absorbance"
  ) %>%
  dplyr::mutate(
    indice = as.integer(gsub("x", "", variable)),
    wavelength = wl[indice]
  )

# ------------------------------------------------------------
# 3. Graficar espectros crudos
# ------------------------------------------------------------

g_espectros <- ggplot(
  df_long,
  aes(x = wavelength, y = absorbance, group = id)
) +
  geom_line(alpha = 0.35) +
  theme_minimal() +
  labs(
    title = "Espectros NIR reales - Gasoline",
    x = "Longitud de onda aproximada",
    y = "Absorbancia"
  )

print(g_espectros)

# ------------------------------------------------------------
# 4. Modelo PLS
# ------------------------------------------------------------

df_modelo <- df %>%
  dplyr::select(y, dplyr::all_of(x_names))

modelo_pls <- pls::plsr(
  y ~ .,
  data = df_modelo,
  scale = TRUE,
  validation = "LOO",
  ncomp = min(15, n - 1)
)

# ------------------------------------------------------------
# 5. Selección de componentes
# ------------------------------------------------------------

rmsep_obj <- pls::RMSEP(modelo_pls)
rmsep_vec <- as.numeric(rmsep_obj$val[1, 1, ])

tabla_rmsep <- data.frame(
  componentes = 0:(length(rmsep_vec) - 1),
  RMSEP = rmsep_vec
)

tabla_rmsep_sin_0 <- tabla_rmsep %>%
  filter(componentes >= 1)

opt_comp <- tabla_rmsep_sin_0$componentes[
  which.min(tabla_rmsep_sin_0$RMSEP)
]

cat("Componentes PLS óptimas:", opt_comp, "\n")

g_rmsep <- ggplot(
  tabla_rmsep_sin_0,
  aes(x = componentes, y = RMSEP)
) +
  geom_line() +
  geom_point(size = 2) +
  geom_vline(xintercept = opt_comp, linetype = "dashed") +
  theme_minimal() +
  labs(
    title = "Selección de componentes PLS",
    x = "Número de componentes",
    y = "RMSEP"
  )

print(g_rmsep)

# ------------------------------------------------------------
# 6. Scores PLS
# ------------------------------------------------------------

scores_mat <- pls::scores(modelo_pls)

scores_opt <- scores_mat[, seq_len(opt_comp), drop = FALSE]

scores_pls <- as.data.frame(scores_opt)
names(scores_pls) <- paste0("Comp", seq_len(opt_comp))

scores_pls$id <- df$id
scores_pls$y <- df$y

# ------------------------------------------------------------
# 7. Selección de número de clusters
# ------------------------------------------------------------

comp_names <- paste0("Comp", seq_len(opt_comp))

X_cluster <- scale(scores_pls[, comp_names, drop = FALSE])

k_grid <- 2:8

tabla_k <- data.frame(
  k = k_grid,
  WSS = NA_real_,
  Silhouette = NA_real_
)

for (i in seq_along(k_grid)) {
  k <- k_grid[i]
  km_temp <- kmeans(
    X_cluster,
    centers = k,
    nstart = 50
  )
  tabla_k$WSS[i] <- km_temp$tot.withinss
  sil_temp <- cluster::silhouette(
    km_temp$cluster,
    dist(X_cluster)
  )
  tabla_k$Silhouette[i] <- mean(sil_temp[, 3])
}

k_opt <- tabla_k$k[which.max(tabla_k$Silhouette)]

cat("Número óptimo de clusters:", k_opt, "\n")

g_wss <- ggplot(tabla_k, aes(x = k, y = WSS)) +
  geom_line() +
  geom_point(size = 2) +
  theme_minimal() +
  labs(
    title = "Método del codo",
    x = "Número de clusters",
    y = "WSS"
  )

print(g_wss)

g_sil <- ggplot(tabla_k, aes(x = k, y = Silhouette)) +
  geom_line() +
  geom_point(size = 2) +
  geom_vline(xintercept = k_opt, linetype = "dashed") +
  theme_minimal() +
  labs(
    title = "Selección de clusters por silhouette",
    x = "Número de clusters",
    y = "Silhouette promedio"
  )

print(g_sil)

# ------------------------------------------------------------
# 8. Clustering final
# ------------------------------------------------------------

set.seed(123)

km_final <- kmeans(
  X_cluster,
  centers = k_opt,
  nstart = 100
)

df$cluster <- factor(km_final$cluster)
scores_pls$cluster <- factor(km_final$cluster)

# ------------------------------------------------------------
# 9. Boxplot de octano por cluster
# ------------------------------------------------------------

g_boxplot <- ggplot(
  df,
  aes(x = cluster, y = y, fill = cluster)
) +
  geom_boxplot(alpha = 0.75) +
  geom_jitter(width = 0.12, alpha = 0.55, size = 1.8) +
  theme_minimal() +
  guides(fill = "none") +
  labs(
    title = "Número de octano según cluster",
    x = "Cluster",
    y = "Octano"
  )

print(g_boxplot)

# ------------------------------------------------------------
# 10. Resumen por cluster
# ------------------------------------------------------------

resumen_cluster <- df %>%
  group_by(cluster) %>%
  summarise(
    n = n(),
    media = mean(y),
    mediana = median(y),
    desviacion = sd(y),
    minimo = min(y),
    maximo = max(y),
    .groups = "drop"
  )

print(resumen_cluster)

# ------------------------------------------------------------
# 11. ANOVA
# ------------------------------------------------------------

cat("\nANOVA de octano según cluster:\n")
print(summary(aov(y ~ cluster, data = df)))

# ------------------------------------------------------------
# 12. Scores PLS coloreados
# ------------------------------------------------------------

if (opt_comp >= 2) {
  g_scores <- ggplot(
    scores_pls,
    aes(x = Comp1, y = Comp2, color = cluster)
  ) +
    geom_point(size = 3, alpha = 0.85) +
    theme_minimal() +
    labs(
      title = "Scores PLS coloreados por cluster",
      x = "Componente PLS 1",
      y = "Componente PLS 2",
      color = "Cluster"
    )
} else {
  g_scores <- ggplot(
    scores_pls,
    aes(x = Comp1, y = y, color = cluster)
  ) +
    geom_point(size = 3, alpha = 0.85) +
    theme_minimal() +
    labs(
      title = "Score PLS 1 vs octano",
      x = "Componente PLS 1",
      y = "Octano",
      color = "Cluster"
    )
}

print(g_scores)

# ------------------------------------------------------------
# 13. Espectros coloreados por cluster
# ------------------------------------------------------------

df_long_cluster <- df %>%
  dplyr::select(id, cluster, dplyr::all_of(x_names)) %>%
  tidyr::pivot_longer(
    cols = dplyr::all_of(x_names),
    names_to = "variable",
    values_to = "absorbance"
  ) %>%
  dplyr::mutate(
    indice = as.integer(gsub("x", "", variable)),
    wavelength = wl[indice]
  )

g_espectros_cluster <- ggplot(
  df_long_cluster,
  aes(
    x = wavelength,
    y = absorbance,
    group = id,
    color = cluster
  )
) +
  geom_line(alpha = 0.45) +
  theme_minimal() +
  labs(
    title = "Espectros NIR coloreados por cluster",
    x = "Longitud de onda aproximada",
    y = "Absorbancia",
    color = "Cluster"
  )

print(g_espectros_cluster)

# ------------------------------------------------------------
# 14. Espectro promedio por cluster
# ------------------------------------------------------------

df_mean_spectra <- df_long_cluster %>%
  group_by(cluster, wavelength) %>%
  summarise(
    mean_absorbance = mean(absorbance),
    .groups = "drop"
  )

g_mean_spectra <- ggplot(
  df_mean_spectra,
  aes(
    x = wavelength,
    y = mean_absorbance,
    color = cluster
  )
) +
  geom_line(linewidth = 1.2) +
  theme_minimal() +
  labs(
    title = "Espectro promedio por cluster",
    x = "Longitud de onda aproximada",
    y = "Absorbancia promedio",
    color = "Cluster"
  )

print(g_mean_spectra)