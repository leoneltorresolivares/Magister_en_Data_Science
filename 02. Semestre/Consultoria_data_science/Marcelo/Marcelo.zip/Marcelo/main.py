import requests
from bs4 import BeautifulSoup
import pandas as pd

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Accept-Language": "es-CL,es;q=0.9,en;q=0.8",
    "Referer": "https://www.google.com/",
}

lista = []

# ---------- SCRAPEAR PAGINAS 1 A 10 ----------
for pagina in range(1, 11):   # 1 → 10
    desde = (pagina - 1) * 50 + 1  # MercadoLibre usa rangos así: 1, 51, 101...

    url = f"https://listado.mercadolibre.cl/cafe?_Desde={desde}"
    print(f"Scrapeando página {pagina}: {url}")

    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        print(f"Error en página {pagina} (status {response.status_code})")
        continue

    soup = BeautifulSoup(response.text, "html.parser")

    main = soup.find("div", class_="ui-search")
    if not main:
        print("No encontró el main container, saltando página...")
        continue

    productos = main.find("ol", class_="ui-search-layout ui-search-layout--stack")
    if not productos:
        print("No encontró la lista de productos")
        continue

    productos = productos.find_all("li")

    # ---------- EXTRAER PRODUCTOS ----------
    for p in productos:

        titulo_tag = p.find("h2") or p.find("h3")
        titulo = titulo_tag.get_text(strip=True) if titulo_tag else None

        precio_tag = p.find("span", class_="andes-money-amount__fraction")
        precio = precio_tag.get_text(strip=True) if precio_tag else None

        precio_prev_tag = p.find("s", class_="andes-money-amount--previous")
        precio_anterior = None
        if precio_prev_tag:
            prev_fraction = precio_prev_tag.find("span", class_="andes-money-amount__fraction")
            precio_anterior = prev_fraction.get_text(strip=True) if prev_fraction else None

        descuento_tag = p.find("span", class_="andes-money-amount__discount")
        descuento = descuento_tag.get_text(strip=True) if descuento_tag else None

        link_tag = p.find("a", href=True)
        link = link_tag["href"] if link_tag else None

        puntuacion_tag = p.find("span", class_="poly-component__review-compacted")
        puntuacion = puntuacion_tag.get_text(strip=True) if puntuacion_tag else None

        envio_tag = p.find("span", class_="poly-shipping--next_day")
        envio = envio_tag.get_text(strip=True) if envio_tag else None

        lista.append({
            "titulo": titulo,
            "precio": precio,
            "precio_anterior": precio_anterior,
            "descuento": descuento,
            "link": link,
            "puntuacion": puntuacion,
            "envio": envio,
        })

# ---------- GUARDAR ----------
df = pd.DataFrame(lista)
print(df.shape)

df.to_csv("C:/Users/Leo Tactics/OneDrive/Escritorio/productos_ml.csv",
          index=False,
          encoding="utf-8")

print("Scraping completado")