# Ejercicio de munich diapo 53 clase 1


rm(list = ls())


ruta <- "C:/Users/19990772/Desktop/Mg Data Science/Segundo semestre/Modelos Lineales/Profe Sergio"


setwd(ruta)


library(ggplot2)
library(dplyr)
library(ggpubr) #Grafico corr
library(ggcorrplot) # Grafico corr con valor p
library(gridExtra) #Grilla para varios gráficos en uno


df <- read.csv("C:/Users/19990772/Desktop/Mg Data Science/Segundo semestre/Modelos Lineales/Profe Sergio/munich.txt", sep="")


df2 <- df %>% filter(calefaccion == 0) %>% filter(ubicacion == 2) %>% filter (area >= 80)


boxplot(df2$arriendo)
summary(df2$arriendo)


df$ubicacion <- as.factor(df$ubicacion)


df$calefaccion <- as.factor(df$calefaccion)


# EDA ---------
# Univariado ------

# Hacer bonito

g1 <- ggplot(df, aes(y = arriendo)) + 
  geom_boxplot(fill = "#87CEFA", color = "gray30", width = 0.2, outlier.color = "red", outlier.shape = 16) +
  labs(title = "Boxplot arriendo",
       y = "Arriendo") +
  theme_minimal(base_size = 13) +
  theme(
    axis.title.x = element_blank(),
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank(),
    plot.title = element_text(hjust = 0.5, face = "bold")
  )


g2 <- ggplot(df, aes(y = area)) + 
  geom_boxplot(fill = "#87CEFA", color = "gray30", width = 0.2, outlier.color = "red", outlier.shape = 16) +
  labs(title = "Boxplot Área",
       y = "m2") +
  theme_minimal(base_size = 13) +
  theme(
    axis.title.x = element_blank(),
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank(),
    plot.title = element_text(hjust = 0.5, face = "bold")
  )

g3 <- ggplot(df, aes(x = calefaccion, fill = calefaccion)) +
  geom_bar(width = 0.6, alpha = 0.8) +
  geom_text(
    stat = "count",
    aes(label = ..count..),
    vjust = 1.5,          # hacia abajo (dentro de la barra)
    color = "black",      # texto blanco para contrastar
    size = 4
  ) +
  labs(title = "Distribución de Categorías calefacción",
       x = "Categoría",
       y = "Frecuencia") +
  scale_fill_brewer(palette = "Pastel2") +
  theme_minimal(base_size = 13) +
  theme(
    legend.position = "none",
    plot.title = element_text(face = "bold", hjust = 0.5),
    axis.text = element_text(color = "gray20"),
    axis.title = element_text(face = "bold")
  )


g4 <- ggplot(df, aes(x = ubicacion, fill = ubicacion)) +
  geom_bar(width = 0.6, alpha = 0.8) +
  geom_text(
    stat = "count",
    aes(label = ..count..),
    vjust = 1.5,          # hacia abajo (dentro de la barra)
    color = "black",      # texto blanco para contrastar
    size = 4
  ) +
  labs(title = "Distribución de Categorías ubicación",
       x = "Categoría",
       y = "Frecuencia") +
  scale_fill_brewer(palette = "Pastel2") +
  theme_minimal(base_size = 13) +
  theme(
    legend.position = "none",
    plot.title = element_text(face = "bold", hjust = 0.5),
    axis.text = element_text(color = "gray20"),
    axis.title = element_text(face = "bold")
  )


grid.arrange(g1, g2, g3, g4, ncol = 2)


# Corr -------


# Correlaciones solo númericas y categoricas si tiene 2 niveles (0 y 1, recodificar en caso de ser necesario)


# Correlación de pearson estandar


df_corr <- df[,c("arriendo", "area", "calefaccion")]


df_corr$calefaccion <- as.numeric(df_corr$calefaccion)

  
corr_matrix <- cor(df_corr)


ggcorrplot(corr_matrix, hc.order = TRUE, type = "lower",
           lab = TRUE, lab_size = 3, 
           colors = c("red", "white", "blue"),
           title = "Matriz de Correlación",
           ggtheme = theme_minimal())


# Correlación con valor p
p_matrix <- cor_pmat(df_corr)


ggcorrplot(corr_matrix, 
           hc.order = TRUE, type = "lower",
           lab = TRUE, lab_size = 3,
           p.mat = p_matrix, sig.level = 0.05,
           insig = "blank",
           colors = c("red", "white", "blue"),
           title = "Matriz de Correlación con Significancia",
           ggtheme = theme_minimal())


# bivaraido -----


# Numerica con numerica


# Clasico
ggplot(df, aes(x = area, y = arriendo))+
  geom_point(alpha = 0.6)+
  geom_smooth(method = "lm", se = F, color = "blue")+
  theme_minimal()+
  labs(title = "Arriendo vs área")


# No clasico (mejor el clasico)
ggplot(df, aes(x = area, y = arriendo)) +
  geom_hex() +
  scale_fill_viridis_c() +
  theme_minimal()


# numericas y categoricas 
# Violin, mejor boxplot por cantidad de niveles categoricos
ggplot(df, aes(x = ubicacion, y = arriendo, fill = ubicacion)) +
  #geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot( color = "black", alpha = 0.7) +
  theme_minimal()+
  labs(title = "Arriendo por ubicación")


library(lsr)
modelo <- aov(arriendo ~ ubicacion, data = df)
etaSquared(modelo)


# categoricas con categoricas

tabla <- table(df$calefaccion, df$ubicacion)
chisq.test(tabla)



library(ggridges)
ggplot(df, aes(x = arriendo, y = ubicacion, fill = ubicacion)) +
  geom_density_ridges(alpha = 0.6) +
  theme_minimal()+
  labs(title = "Gráfico distribución por ubicación")



# Escribir el modelo -------

# Y_i = B_0 + B_1*Area_i + B_2*Calef_i + B_3*Ubic1_i + B_4*Ubic2_i + B_5*Ubic3_i + e_i

# Donde

# Y_i: Valor del arriendo del hogar i (en euros)
# Area_i: Área total del inmueble i (en m2)
# Calef_i: Variable binaria que indica si el inmueble tiene calefacción o no
# Ubic_i: Variable categorica que indica el lugar geografico del inmueble


# Matriz de diseño


unos <- rep(1, times = nrow(df))


matriz_diseño <- cbind(unos, df[,c("area", "calefaccion", "ubicacion")])


str(matriz_diseño)


variable_dependiente <- df$arriendo


# Ajustar el modelo mediante lm, luego realizar el test F y concluir


data_final <- cbind(variable_dependiente, matriz_diseño)


str(data_final)


modelo <- lm(variable_dependiente ~ 0 + unos + area + calefaccion + ubicacion, data = data_final) # El 0 es para que reconozca la columna de unos imputada manualmente


modelo2 <- lm(arriendo ~ area + calefaccion + ubicacion, data = df) # Clasico


summary(modelo)
summary(modelo2)


# Estadistico F valor p < 2.2e-16, al menos un beta es significativo

# area, calefaccion1 y ubicacion3 son estadisticamente significativos, cada 3.64 aumenta el precio, tener calefaccion (supongo que el 1 es si)
# aumenta el precio en 164, estar en la ubicacion 3 aumenta en 167 el arriendo
# r-squared 0.3567, mucha variabilidad no explicada

model.matrix(arriendo ~ area + calefaccion + ubicacion, data = df) # Columna de unos


# Siguiendo con munich diapo 60 -------------


nuevo_hogar <- tibble(
  area = 80,
  calefaccion = factor(0, levels = c(0,1)),
  ubicacion = factor(2, levels = 1:3)
)


predict(modelo2, newdata = nuevo_hogar, interval = "confidence", level = 0.95) # Ver que tan buena es la predicción


predicciones <- predict(modelo2, newdata = df, interval = "confidence")
df_plot_full <- cbind(df, predicciones)


ggplot(df_plot_full, aes(x = area, y = arriendo)) +
  geom_point(color = "blue", size = 2) +                   # valores reales
  geom_line(aes(y = fit), color = "red", size = 1) +       # predicción
  geom_ribbon(aes(ymin = lwr, ymax = upr), alpha = 0.2) + # intervalo confianza
  labs(title = "Predicción vs Valores Reales",
       x = "Área",
       y = "Arriendo") +
  theme_minimal()


df2$calefaccion <- as.factor(df2$calefaccion)
df2$ubicacion <- as.factor(df2$ubicacion)


pred <- predict(modelo2, newdata = df2, interval = "confidence")


df_plot <- cbind(df2, pred)


ggplot(df_plot, aes(x = area, y = arriendo)) +
  geom_point(color = "blue", size = 2) +                   # valores reales
  geom_line(aes(y = fit), color = "red", size = 1) +       # predicción
  geom_ribbon(aes(ymin = lwr, ymax = upr), alpha = 0.2) + # intervalo confianza
  labs(title = "Predicción vs Valores Reales",
       x = "Área",
       y = "Arriendo") +
  theme_minimal()


#obtener la fila de la matriz de diseño para newdata (incluye intercepto y dummies en el mismo orden)
x0_mat <- model.matrix(~ area + calefaccion + ubicacion, data = nuevo_hogar) # devuelve 1 x p


#coeficientes y matriz de covarianza de betas estimadas
beta_hat <- coef(modelo2)           # vector p x 1
V_beta   <- vcov(modelo2)           # matriz p x p = Var(hat beta) estimada


#estimador puntual
mu_hat <- as.numeric(x0_mat %*% beta_hat)


#error estándar de mu_hat
se_mu_hat <- sqrt( as.numeric( x0_mat %*% V_beta %*% t(x0_mat) ) )


#grados de libertad residuales y t-critico
df_resid <- df.residual(modelo2)                # n - p - 1
t_crit   <- qt(0.975, df = df_resid)


#intervalo de confianza del 95% para la media (mu0)
ci_lower <- mu_hat - t_crit * se_mu_hat
ci_upper <- mu_hat + t_crit * se_mu_hat
c(fit = mu_hat, lwr = ci_lower, upr = ci_upper)


# El intervalo al 95% cuando los parametros son conocidos es 

# mu - 1.96 * sigma, u + 1.96 * sigma











