rm(list = ls())


ruta <- "C:/Users/19990772/Desktop/Mg Data Science/Segundo semestre/Modelos Lineales/Profe Jose/Peces"


setwd(ruta)


library(ggplot2)
library(dplyr)
library(scales)
library(MASS)


df <- read.csv("C:/Users/19990772/Desktop/Mg Data Science/Segundo semestre/Modelos Lineales/Profe Jose/Peces/largo_peces.txt", sep="")


df$temp <- as.factor(df$temp)


# No siempre dan el mismo modelo
# Usar varios modelos, cambiar los nombres y comparar
# hacer el eda


# EDA -------------

str(df)

library(DataExplorer)


plot_intro(df)          # resumen general
plot_histogram(df)      # histogramas para variables numéricas

library(tidyr)
library(ggpubr) #Grafico corr
library(ggcorrplot) # Grafico corr con valor p
library(gridExtra) #Grilla para varios gráficos en uno



g1 = ggplot(df, aes(y = largo)) + 
  geom_boxplot(fill = "#87CEFA", color = "gray30", width = 0.2, outlier.color = "red", outlier.shape = 16) +
  labs(title = "Boxplot largo del pez",
       y = "Largo en cm") +
  theme_minimal(base_size = 13) +
  theme(
    axis.title.x = element_blank(),
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank(),
    plot.title = element_text(hjust = 0.5, face = "bold")
  )


g2 = ggplot(df, aes(y = edad)) + 
  geom_boxplot(fill = "#87CEFA", color = "gray30", width = 0.2, outlier.color = "red", outlier.shape = 16) +
  labs(title = "Boxplot edad del pez",
       y = "Edad en días") +
  theme_minimal(base_size = 13) +
  theme(
    axis.title.x = element_blank(),
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank(),
    plot.title = element_text(hjust = 0.5, face = "bold")
  )


# numericas y categoricas 
g3 = ggplot(df, aes(x = temp, y = largo, fill = temp)) +
  #geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot( color = "black", alpha = 0.7) +
  theme_minimal()+
  labs(title = "Largo del pez por temperatura")


g4 = ggplot(df, aes(x = temp, y = edad, fill = temp)) +
  #geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot( color = "black", alpha = 0.7) +
  theme_minimal()+
  labs(title = "Edad del pez por temperatura")


grid.arrange(g1, g2, g3, g4, ncol = 2)


df_ = df[,c("edad","largo")]


df_corr = cor(df_)


ggcorrplot(df_corr, hc.order = TRUE, type = "lower",
           lab = TRUE, lab_size = 3, 
           colors = c("red", "white", "blue"),
           title = "Matriz de Correlación",
           ggtheme = theme_minimal())


p_matrix <- cor_pmat(df_)


ggcorrplot(df_corr, 
           hc.order = TRUE, type = "lower",
           lab = TRUE, lab_size = 3,
           p.mat = p_matrix, sig.level = 0.05,
           insig = "blank",
           colors = c("red", "white", "blue"),
           title = "Matriz de Correlación con Significancia",
           ggtheme = theme_minimal())


ggplot(df, aes(x = edad, y = largo))+
  geom_point(alpha = 0.6)+
  geom_smooth(method = "lm", se = F, color = "blue")+
  theme_minimal()+
  labs(title = "Edad vs Largo")



# Ahora modelos ---------

# forward ---------

# Se agrega el menor valor si es significativo (valor p)

modelo = lm(largo ~ 1, data = df)
add1(modelo, ~. + edad + temp, test = "F")


modelo = lm(largo ~ edad, data = df)
add1(modelo, ~. + temp, test = "F")


modelo = lm(largo ~ edad + temp, data = df)


# backward


modelo_back = lm(largo ~ edad + temp, data = df)
drop1(modelo_back, test = "F") # Aqui vamos eliminando de manera manual los parametros
# Se elimina el mayor valor p si es significativo


# Metricas ------------

# R2 ajustado


summary(modelo)
summary(modelo_back)


summary(aov(largo ~ edad + temp, data = df))


#cp de mallows


sigma2_gorro_modelo = summary(modelo)$sigma^2
e_modelo = resid(modelo)
sce_modelo = sum(e_modelo*e_modelo)
p_modelo = length(coef(modelo))
n_modelo = nrow(df)
cp_modelo = (sce_modelo/sigma2_gorro_modelo)+2*p_modelo-n_modelo #tiene que dar aprox al numero de coef


sigma2_gorro_modelo_back = summary(modelo_back)$sigma^2
e_modelo_back = resid(modelo_back)
sce_modelo_back = sum(e_modelo_back*e_modelo_back)
p_modelo_back = length(coef(modelo_back))
n_modelo_back = nrow(df)
cp_modelo_back = (sce_modelo_back/sigma2_gorro_modelo_back)+2*p_modelo_back-n_modelo_back #tiene que dar aprox al numero de coef


cp_modelo
cp_modelo_back


# estadistico press

h_modelo = ls.diag(modelo)$hat
sum((e_modelo/1-h_modelo)^2) #debe ser pequeño, relativo


h_modelo_back = ls.diag(modelo_back)$hat
sum((e_modelo_back/1-h_modelo_back)^2) #debe ser pequeño, relativo

# AIC Y BIC

AIC(modelo)
AIC(modelo_back)


BIC(modelo)
BIC(modelo_back)
























