# Trabajo 2 modelos linelaes


rm(list = ls())


ruta <- "C:/Users/19990772/Desktop/Mg Data Science/Segundo semestre/Modelos Lineales/Profe Ledys/Tarea 2"


setwd(ruta)


library(ggplot2)
library(dplyr)
library(scales)
library(readxl)


df <- tibble(read_excel("Casen 2017_Muestra.xlsx", 
                        sheet = "Base_Casen"))



columnas_de_interes <- c("s12", "r3", "ypch")


data <- df[,columnas_de_interes]


str(data)


data$s12[data$s12 < 6] <- "Público"


data$s12[data$s12 == "6"] <- "Privado"
data$s12[data$s12 == "7"] <- "Privado"
data$s12[data$s12 == "8"] <- "Privado"


data$s12[data$s12 == "9"] <- "Otro"

data$s12[data$s12 == "99"] <- "Otro"

data$r3[data$r3 < 10] <- "Indigena"
data$r3[data$r3 == "10"] <- "No indigena"
data$r3[data$r3 == "99"] <- "No sabe"

# Univariado ------------
# Variable dependiente (sistema de salud)


tabla <- table(data$s12)
prop.table(tabla)
barplot(tabla)


# Variable categorica descendencia


barplot(table(data$r3))


# Variable numerica ingresos


hist(data$ypch)


ggplot(data, aes(x = ypch)) +
  geom_histogram(
    bins = 30,
    fill = "steelblue",
    color = "white",
    alpha = 0.8
  ) +
  geom_text(
    stat = "bin",
    bins = 30,
    aes(label = ifelse(..count.. > 0, ..count.., "")),  # 👈 oculta los ceros
    vjust = -0.5,
    size = 3.5,
    color = "black"
  ) +
  scale_x_continuous(labels = scales::comma) +
  labs(
    title = "Distribución del Ingreso per cápita",
    x = "Ingreso per cápita (pesos chilenos)",
    y = "Frecuencia"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold")
  )




# Bi-variado -----------

data %>%
  count(r3, s12) %>%
  group_by(r3) %>%
  mutate(pct = n / sum(n)) %>%
  ggplot(aes(x = r3, y = pct, fill = s12)) +
  geom_bar(stat = "identity", position = "fill") +
  geom_text(aes(label = scales::percent(pct, accuracy = 1)),
            position = position_fill(vjust = 0.5),
            color = "white", size = 4) +
  scale_y_continuous(labels = scales::percent) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold")
  ) +
  labs(
    title = "Proporción del Sistema de Salud según Etnia",
    x = "Etnia",
    y = "Proporción",
    fill = "Sistema de Salud"
  )

# Mejorar el numero del ingreso (no en notación) y quitar el atipico al final que caga la visualización
ggplot(data, aes(x = s12, y = ypch, fill = s12)) +
  geom_boxplot(alpha = 0.7, outlier.color = "red") +
  scale_y_continuous(labels = scales::comma) +
  coord_cartesian(ylim = c(0, 2000000)) + 
  labs(
    title = "Distribución del Ingreso según Sistema de Salud",
    x = "Sistema de Salud",
    y = "Ingreso per cápita (pesos chilenos)"
  ) +
  theme_minimal() +
  theme(legend.position = "none")


# Test------------

# Test proporcional -----------
# Primero el categorico-categorico es obvio lo que iba a pasar, pero como dice la profe Ledys, no esta mal, solo esta de acuerdo
# a la literatura

# inspeccionar codificación rápida
table(data$s12, useNA = "ifany")
table(data$r3, useNA = "ifany")
unique(data$s12)
unique(data$r3)


df2 <- data %>%
  filter(s12 %in% c("Privado", "Público"),    # solo categorías relevantes
         r3 %in% c("Indigena", "No indigena")) %>%   # quitamos "No sabe"
  mutate(
    Sistema = ifelse(s12 == "Público", "Publico", "Privado"),
    Etnia_bin = ifelse(r3 == "Indigena", "Indigena", "No_Indigena")
  )

res_por_etnia <- df2 %>%
  group_by(Etnia_bin) %>%
  summarise(
    n_public = sum(Sistema == "Publico"),
    n_total  = n(),
    .groups = "drop"
  ) %>%
  mutate(
    p_hat = n_public / n_total,
    p0 = 0.5,
    se = sqrt(p0 * (1 - p0) / n_total),
    z = (p_hat - p0) / se,
    p_value = pnorm(z),
    decision = ifelse(p_value < 0.05,
                      "Rechazar H0 (público ≤ privado)",
                      "No rechazar H0 (público > privado)")
  )

print(res_por_etnia)

# ejemplo con indígenas
tab_ind <- df2 %>% filter(Etnia_bin == "Indigena")
prop.test(sum(tab_ind$Sistema == "Publico"),
          nrow(tab_ind),
          p = 0.5,
          alternative = "less",
          correct = FALSE)



df_total <- data %>%
  filter(s12 %in% c("Privado", "Público")) %>%
  mutate(Sistema = ifelse(s12 == "Público", "Publico", "Privado"))


n_public <- sum(df_total$Sistema == "Publico")
n_total  <- nrow(df_total)

prop.test(x = n_public,
          n = n_total,
          p = 0.5,
          alternative = "less",
          correct = FALSE)



# Test ingresos ----------

str(data)

df2 <- data %>%
  filter(s12 %in% c("Público", "Privado")) %>%
  mutate(
    Sistema = ifelse(s12 == "Público", "Publico", "Privado"),
    Ingreso = as.numeric(ypch)   # convierte a num si hace falta
  ) %>%
  filter(!is.na(ypch))


resumen <- df2 %>%
  group_by(Sistema) %>%
  summarise(
    n = n(),
    media = mean(Ingreso, na.rm = TRUE),
    sd = sd(Ingreso, na.rm = TRUE),
    mediana = median(Ingreso, na.rm = TRUE),
    IQR = IQR(Ingreso, na.rm = TRUE)
  )
print(resumen)


shapiro_priv <- shapiro.test(df2$Ingreso[df2$Sistema == "Privado"])
shapiro_pub  <- shapiro.test(df2$Ingreso[df2$Sistema == "Publico"])

shapiro_priv
shapiro_pub


# vectores por grupo
ing_priv <- df2$Ingreso[df2$Sistema == "Privado"]
ing_pub  <- df2$Ingreso[df2$Sistema == "Publico"]

t_welch <- t.test(ing_priv, ing_pub,
                  alternative = "less",   # H1: mu_priv < mu_pub
                  var.equal = FALSE,      # Welch
                  conf.level = 0.95)

t_welch












