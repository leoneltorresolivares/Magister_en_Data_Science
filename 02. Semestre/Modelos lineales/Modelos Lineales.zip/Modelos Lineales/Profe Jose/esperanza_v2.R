rm(list = ls())


ruta <- "C:/Users/Leo Tactics/OneDrive/Escritorio/Modelos Lineales/Profe Jose/Trabajo esperanza"


setwd(ruta)

library(ggplot2)
library(dplyr)
library(scales)
library(MASS)


df <- read.csv("C:/Users/Leo Tactics/OneDrive/Escritorio/Modelos Lineales/Profe Jose/Trabajo esperanza/esperanza.txt", sep="")

# No siempre dan el mismo modelo
# Usar varios modelos, cambiar los nombres y comparar
# hacer el eda

# Modelo ----------


#df <- df[,-9]

# No siempre dan el mismo modelo
# Usar varios modelos, cambiar los nombres y comparar
# hacer el eda

# Forward
modelo = lm(esp_vida ~ 1, data = df)
add1(modelo, ~. + habitantes + ingresos + analfabetismo +asesinatos + universitarios + heladas + area + densidad_pobl, test = "F")

modelo = lm(esp_vida ~ asesinatos, data = df)
add1(modelo, ~. + habitantes + ingresos + analfabetismo + universitarios + heladas + area, test = "F")

modelo = lm(esp_vida ~ asesinatos + universitarios, data = df)
add1(modelo, ~. + habitantes + ingresos + analfabetismo + heladas + area, test = "F")

modelo = lm(esp_vida ~ asesinatos + universitarios + heladas, data = df)
add1(modelo, ~. + habitantes + ingresos + analfabetismo + area, test = "F")

#backward
modelo <- lm(esp_vida ~ habitantes + ingresos + analfabetismo + asesinatos + universitarios + heladas + area + densidad_pobl, test = "F", data = df)
#summary(modelo)
drop1(modelo, test = "F") # Aqui vamos eliminando de manera manual los parametros

modelo <- lm(esp_vida ~ habitantes + ingresos + asesinatos + universitarios + heladas + area + densidad_pobl, test = "F", data = df)
drop1(modelo, test = "F")

modelo <- lm(esp_vida ~ habitantes + ingresos + asesinatos + universitarios + heladas + densidad_pobl, test = "F", data = df)
drop1(modelo, test = "F")

modelo <- lm(esp_vida ~ habitantes + asesinatos + universitarios + heladas + densidad_pobl, test = "F", data = df)
drop1(modelo, test = "F")

modelo <- lm(esp_vida ~ habitantes + asesinatos + universitarios + heladas, test = "F", data = df)
drop1(modelo, test = "F")

modelo <- lm(esp_vida ~ asesinatos + universitarios + heladas, test = "F", data = df)
drop1(modelo, test = "F")

#Stepwise

modelo = lm(esp_vida ~ 1, data = df)
add1(modelo, ~. + habitantes + ingresos + analfabetismo +asesinatos + universitarios + heladas + area, test = "F")

modelo = lm(esp_vida ~ asesinatos, data = df)
add1(modelo, ~. + habitantes + ingresos + analfabetismo + universitarios + heladas + area, test = "F")

modelo = lm(esp_vida~asesinatos, data =df)
drop1(modelo, test = "F") #Por criterio se mantiene agregando, no se detiene

modelo = lm(esp_vida ~ asesinatos + universitarios, data = df)
add1(modelo, ~. + habitantes + ingresos + analfabetismo + heladas + area, test = "F")

modelo = lm(esp_vida ~ asesinatos + universitarios, data = df)
drop1(modelo, test = "F")

modelo = lm(esp_vida ~ asesinatos + universitarios + heladas, data = df)
add1(modelo, ~. + habitantes + ingresos + analfabetismo + area, test = "F")

modelo = lm(esp_vida ~ asesinatos + universitarios + heladas, data = df)
drop1(modelo, test = "F")

modelo = lm(esp_vida ~ asesinatos + universitarios + heladas + habitantes, data = df)
add1(modelo, ~. + habitantes + ingresos + analfabetismo + area, test = "F")


modelo = lm(esp_vida ~ asesinatos + universitarios + heladas + habitantes, data = df)
drop1(modelo, test = "F")


# Metricas ------------

# R2 ajustado


summary(modelo)


summary(aov(esp_vida ~ asesinatos + universitarios + heladas + habitantes, data = df))


#cp de mallows


modelo_completo = lm(esp_vida ~ habitantes + ingresos + analfabetismo +asesinatos + universitarios + heladas + area + densidad_pobl, data = df, test = "F")
sigma2_gorro = summary(modelo_completo)$sigma^2
e = resid(modelo)
sce = sum(e*e)
p = length(coef(modelo))
n = nrow(df)
cp = (sce/sigma2_gorro)+2*p-n #tiene que dar aprox al numero de coef

# estadistico press

h = ls.diag(modelo)$hat
sum((e/1-h)^2) #debe ser pequeño, relativo

# AIC Y BIC

AIC(modelo)
BIC(modelo)





# EDA

str(df)

library(DataExplorer)


plot_intro(df)          # resumen general
plot_histogram(df)      # histogramas para variables numéricas

library(tidyr)
library(ggplot2)
library(dplyr)
library(ggpubr) #Grafico corr
library(ggcorrplot) # Grafico corr con valor p
library(gridExtra) #Grilla para varios gráficos en uno


df_num <- df[, sapply(df, is.numeric)]

# Convertimos a formato largo
df_long <- pivot_longer(df_num, cols = everything(),
                        names_to = "Variable", values_to = "Valor")

# Boxplots separados por variable usando facets
ggplot(df_long, aes(x = "", y = Valor, fill = Variable)) +
  geom_boxplot(alpha = 0.7) +
  facet_wrap(~Variable, scales = "free") +  # un panel por variable, escalas independientes
  theme_minimal() +
  labs(title = "Boxplots individuales por variable",
       x = NULL, y = "Valor") +
  theme(axis.text.x = element_blank(),  # quita etiquetas del eje x
        axis.ticks.x = element_blank(),
        legend.position = "none")



df_corr = cor(df)


ggcorrplot(df_corr, hc.order = TRUE, type = "lower",
           lab = TRUE, lab_size = 3, 
           colors = c("red", "white", "blue"),
           title = "Matriz de Correlación",
           ggtheme = theme_minimal())


p_matrix <- cor_pmat(df)


ggcorrplot(df_corr, 
           hc.order = TRUE, type = "lower",
           lab = TRUE, lab_size = 3,
           p.mat = p_matrix, sig.level = 0.05,
           insig = "blank",
           colors = c("red", "white", "blue"),
           title = "Matriz de Correlación con Significancia",
           ggtheme = theme_minimal())















