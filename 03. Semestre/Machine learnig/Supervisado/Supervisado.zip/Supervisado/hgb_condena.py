#!/usr/bin/env python3
"""
Histogram-based Gradient Boosting model with QUANTILE (pinball) loss for
custodial-sentence length on the Chilean Judiciary "Sentencias, Penas y
Beneficios" dataset. Hyper-parameters are tuned with RandomizedSearchCV,
scoring on the pinball loss for the target quantile.

Unlike the linear scripts this fits a non-linear tree ensemble and predicts a
conditional QUANTILE of log1p(days) rather than the mean: --quantile 0.5 (the
default) gives a robust median sentence; refit at e.g. 0.1 and 0.9 to bracket a
prediction interval. Preprocessing also differs (target-encoded high-cardinality
categoricals, raw age) — see utils.build_tree_model.

Data loading, feature engineering, the search and reporting live in utils.py.
See utils.py / CLAUDE.md / Ficha_Tecnica_Sentencias.pdf for the target, feature
set and data caveats.

Usage:
    python hgb_condena.py                              # median, default 2024 file
    python hgb_condena.py --quantile 0.9               # 90th-percentile sentence
    python hgb_condena.py 'data/*.xlsx' --n-iter 30    # all years, bigger search
"""
from __future__ import annotations

from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import make_scorer, mean_pinball_loss

from utils import (
    HGB_PARAM_DIST,
    build_tree_model,
    buscar_hiperparametros,
    load_split,
    parse_args,
    report,
)


def main() -> int:
    args = parse_args(__doc__, add_hgb_args=True)
    if not 0.0 < args.quantile < 1.0:
        raise SystemExit("--quantile must be strictly between 0 and 1")
    X_train, X_test, y_train, y_test = load_split(args)

    estimator = HistGradientBoostingRegressor(
        loss="quantile", quantile=args.quantile, random_state=args.seed,
    )
    pipeline = build_tree_model(estimator)

    # Tune ON the pinball loss for this quantile. greater_is_better=False makes
    # sklearn negate it, so a higher CV score still means a lower loss; r2 would
    # reward a conditional-mean fit, not a quantile one.
    scorer = make_scorer(mean_pinball_loss, alpha=args.quantile, greater_is_better=False)

    print(f"\nFitting HistGradientBoosting (quantile={args.quantile:g}) via "
          f"RandomizedSearchCV ({args.n_iter} samples x {args.cv}-fold)...")
    search = buscar_hiperparametros(
        pipeline, HGB_PARAM_DIST, scoring=scorer,
        n_iter=args.n_iter, cv=args.cv, seed=args.seed,
    )
    search.fit(X_train, y_train)
    print(f"  best pinball loss (CV, log1p-days): {-search.best_score_:.4f}")
    print("  best params:")
    for k, v in sorted(search.best_params_.items()):
        print(f"    {k.removeprefix('reg__')}: {v}")

    report(search.best_estimator_, X_test, y_test, quantile=args.quantile)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
