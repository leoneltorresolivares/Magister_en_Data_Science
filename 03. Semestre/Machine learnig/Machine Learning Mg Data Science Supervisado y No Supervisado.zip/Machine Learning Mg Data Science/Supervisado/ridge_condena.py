#!/usr/bin/env python3
"""
Linear-regression model for custodial-sentence length on the Chilean Judiciary
"Sentencias, Penas y Beneficios" dataset.

Target (y):  total days of imprisonment  = AÑOS*365 + MESES*30 + DIAS
Features (X):
    - EDAD CONDENADO   (numeric)
    - SEXO CONDENADO   (categorical: hombre/mujer)
    - CÓDIGO DELITO    (categorical: crime code)

Only condemnatory rows (RESULTADO SENTENCIA == "Condenado") with a recorded
custodial penalty are used.  See CLAUDE.md / Ficha_Tecnica_Sentencias.pdf for the
data caveats this script relies on (penalty split across AÑOS/MESES/DIAS, optional
sex/age fields, participant-x-delito grain, etc.).

Usage:
    python regresion_condena.py                       # uses the default yearly files below
    python regresion_condena.py "Sentencias Penas Beneficios 2024.xlsx"
    python regresion_condena.py *.xlsx                # combine several years
"""
from __future__ import annotations

import argparse
import glob
import sys

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LinearRegression,Ridge,Lasso
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import RandomizedSearchCV
from scipy.stats import loguniform

SHEET_NAME = "Sentencias Penas Beneficios"

# Exact column headers as they appear in the workbooks.
COL_AGE = "EDAD CONDENADO"
COL_SEX = "SEXO CONDENADO"
COL_DELITO = "CÓDIGO DELITO"
COL_RESULT = "RESULTADO SENTENCIA"
COL_YEARS = "AÑOS"
COL_MONTHS = "MESES"
COL_DAYS = "DIAS"

DEFAULT_FILES = ["data/Sentencias Penas Beneficios 2024.xlsx"]


def load(paths: list[str]) -> pd.DataFrame:
    """Read and concatenate the relevant columns from one or more yearly files."""
    usecols = [COL_AGE, COL_SEX, COL_DELITO, COL_RESULT, COL_YEARS, COL_MONTHS, COL_DAYS]
    frames = []
    for path in paths:
        print(f"  reading {path} ...", flush=True)
        df = pd.read_excel(path, sheet_name=SHEET_NAME, usecols=usecols)
        frames.append(df)
    return pd.concat(frames, ignore_index=True)


def build_dataset(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    """Filter to condemnatory rows and build the X / y matrices."""
    # Keep only condemnatory results ("Condenado").
    df = df[df[COL_RESULT].astype(str).str.strip().str.lower() == "condenado"].copy()

    # Penalty components -> numeric (anything non-numeric becomes 0).
    for col in (COL_YEARS, COL_MONTHS, COL_DAYS):
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    # Target: total custodial days.
    y = df[COL_YEARS] * 365 + df[COL_MONTHS] * 30 + df[COL_DAYS]

    # Age must be numeric; sex/delito kept as strings (optional fields).
    df[COL_AGE] = pd.to_numeric(df[COL_AGE], errors="coerce")
    df[COL_SEX] = df[COL_SEX].astype(str).str.strip().str.lower()
    df[COL_DELITO] = df[COL_DELITO].astype(str).str.strip()

    X = df[[COL_AGE, COL_SEX, COL_DELITO]]

    # Drop rows with no usable age, no penalty, or implausible age.
    mask = (
        X[COL_AGE].notna()
        & X[COL_AGE].between(10, 100)
        & (y > 0) 
        & (y < 365 * 100)  # filter out extreme outliers (e.g. life sentences coded as 9999 years)
        & (df[COL_SEX] != "nan")
    )
    return X[mask], np.log1p(y[mask])


def build_model(model) -> Pipeline:
    pre = ColumnTransformer(
        transformers=[
            ("age", StandardScaler(), [COL_AGE]),
            ("sex", OneHotEncoder(handle_unknown="ignore"), [COL_SEX]),
            # CÓDIGO DELITO is high-cardinality; OneHot stays sparse and unknown
            # codes at predict time are ignored.
            ("delito", OneHotEncoder(handle_unknown="ignore"), [COL_DELITO]),
        ]
    )
    return Pipeline([("pre", pre), ("reg", model)])


def report(model: Pipeline, X_test, y_test) -> None:
    pred = model.predict(X_test)
    rmse = np.sqrt(mean_squared_error(y_test, pred))
    print("\n=== Test-set performance (target = total days of condena) ===")
    print(f"  n_test : {len(y_test):,}")
    print(f"  R^2    : {r2_score(y_test, pred):.4f}")
    print(f"  MAE    : {mean_absolute_error(y_test, pred):,.1f} days")
    print(f"  RMSE   : {rmse:,.1f} days")

    # Interpretable coefficients for the non-delito features.
    pre = model.named_steps["pre"]
    reg = model.named_steps["reg"]
    names = pre.get_feature_names_out()
    coefs = reg.coef_
    print(len(names), len(coefs))
    print(f"\n  intercept: {reg.intercept_:,.1f} days")
    print("  coefficients (age + sex; delito codes omitted):")
    #for name, c in zip(names, coefs):
    #    print(f"    {name:<28} {c:>12,.2f}")
    #print(f"  ({sum(n.startswith('delito__') for n in names)} CÓDIGO DELITO dummy terms not shown)")

param_dist = {'reg__alpha': loguniform(1e-3, 1e3)}

def buscar_mejor_alpha(modelo, nombre):
    """Ejecuta RandomizedSearchCV sobre el pipeline y devuelve el estimador ajustado."""
    pipe = build_model(modelo)
    search = RandomizedSearchCV(
        estimator=pipe,
        param_distributions=param_dist,
        n_iter=100,
        cv=10,
        scoring='r2',
        random_state=42,
        n_jobs=-1,
    )
    return search

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("files", nargs="*", help="xlsx file(s); supports globs")
    parser.add_argument("--test-size", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    patterns = args.files or DEFAULT_FILES
    paths: list[str] = []
    for p in patterns:
        paths.extend(sorted(glob.glob(p)) or [p])
    paths = [p for p in paths if not p.startswith("~$")]
    if not paths:
        print("No input files found.", file=sys.stderr)
        return 1

    print(f"Loading {len(paths)} file(s)...")
    raw = load(paths)
    print(f"  raw rows: {len(raw):,}")

    X, y = build_dataset(raw)
    print(f"  usable condemnatory rows: {len(X):,}")
    print(f"  target days  -> mean {y.mean():,.0f}  median {y.median():,.0f}  max {y.max():,.0f}")
    print(f"  distinct CÓDIGO DELITO: {X[COL_DELITO].nunique():,}")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_size, random_state=args.seed
    )

    print("\nFitting Ridge pipeline...")
    search = buscar_mejor_alpha(Ridge(), "Ridge")
    search.fit(X_train, y_train)
    print(f"  best alpha: {search.best_params_['reg__alpha']:.4g}")
    # `search.best_estimator_` is a Pipeline (pre + reg) already refitted on the
    # full training set by RandomizedSearchCV (refit=True). Use that pipeline
    # for scoring and reporting so preprocessing is applied correctly.
    model = search.best_estimator_
    print(f"  train R^2: {model.score(X_train, y_train):.4f}")

    report(model, X_test, y_test)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
