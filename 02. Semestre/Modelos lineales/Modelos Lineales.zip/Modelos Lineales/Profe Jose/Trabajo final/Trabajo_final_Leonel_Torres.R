# Trabajo final

rm(list = ls())


ruta <- "C:/Users/Leo Tactics/OneDrive/Escritorio/Modelos Lineales/Profe Jose/Trabajo final"
ruta = "C:/Users/19990772/Desktop/Mg Data Science/Segundo semestre/Modelos Lineales/Profe Jose/Trabajo final"


setwd(ruta)


library(ggplot2)
library(dplyr)
library(scales)
library(MASS)


df = file.choose()


df = read.csv(df, sep = "")


# Recordar escribir el contexto del problema en el informe


# 1) Obtenga gráficos para explorar la asociación entre el largo de los peces y sus potenciales predictores. Comente. --------------


str(df)


df$temp = as.factor(df$temp)


library(DataExplorer)


plot_intro(df)          # resumen general
#plot_histogram(df)      # histogramas para variables numéricas

library(tidyr)
library(ggpubr) #Grafico corr
library(ggcorrplot) # Grafico corr con valor p
library(gridExtra) #Grilla para varios gráficos en uno


# Agregar las metricas en el grafico (cm etc)
g1 = ggplot(df, aes(y = largo)) + 
  geom_boxplot(fill = "blue", color = "gray30", width = 0.2, outlier.color = "red", outlier.shape = 16) +
  labs(title = "Boxplot Largo del pez",
       y = "Largo en cm") +
  theme_minimal(base_size = 13) +
  theme(
    axis.title.x = element_blank(),
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank(),
    plot.title = element_text(hjust = 0.5, face = "bold")
  )

summary(df)


g2 = ggplot(df, aes(y = edad)) + 
  geom_boxplot(fill = "blue", color = "gray30", width = 0.2, outlier.color = "red", outlier.shape = 16) +
  labs(title = "Boxplot Edad del pez",
       y = "Edad en días") +
  theme_minimal(base_size = 13) +
  theme(
    axis.title.x = element_blank(),
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank(),
    plot.title = element_text(hjust = 0.5, face = "bold")
  )


# numericas y categoricas 
g3 = ggplot(df, aes(x = temp, y = largo, fill = temp)) +
  #geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot( color = "black", alpha = 0.7) +
  theme_minimal(base_size = 13)+
  labs(title = "Largo del pez por tanque de agua", y = "Largo en cm", x = "Tanque de agua", fill = "Tipo de tanque")+
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold")
  )


g4 = ggplot(df, aes(x = temp, y = edad, fill = temp)) +
  #geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot( color = "black", alpha = 0.7) +
  theme_minimal(base_size = 13)+
  labs(title = "Edad del pez por tanque de de agua", y = "Edad en días", x = "Tanque de agua", fill = "Tipo de tanque")+
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold")
  )


grid.arrange(g1, g2, g3, g4, ncol = 2)


df_ = df[,c("edad","largo")]


df_corr = cor(df_)


# Colocar la correlación en el grafico
ggcorrplot(df_corr, hc.order = TRUE, type = "lower",
           lab = TRUE, lab_size = 3, 
           colors = c("red", "white", "blue"),
           title = "Matriz de Correlación",
           ggtheme = theme_minimal())


p_matrix <- cor_pmat(df_)


# Colocar la significancia en el grafico
ggcorrplot(df_corr, 
           hc.order = TRUE, type = "lower",
           lab = TRUE, lab_size = 3,
           p.mat = p_matrix, sig.level = 0.05,
           insig = "blank",
           colors = c("red", "white", "blue"),
           title = "Matriz de Correlación con Significancia",
           ggtheme = theme_minimal())


g5 = ggplot(df, aes(x = edad, y = largo))+
  geom_point(alpha = 0.6)+
  geom_smooth(method = "lm", se = F, color = "blue")+
  theme_minimal(base_size = 13)+
  labs(title = "Edad vs Largo", y = "Largo en cm", x = "Edad en días")+
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold")
  )


g6 = ggplot(df, aes(x = edad, y = largo, color = temp)) +
  geom_point(alpha = 0.6) +
  #geom_smooth(method = "lm", se = FALSE) +
  theme_minimal(base_size = 13) +
  labs(
    title = "Edad vs Largo por Grupo",
    color = "Tanque",
    y = "Largo en cm",
    x = "Edad en días"
  )+
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold")
  )


grid.arrange(g5, g6, ncol = 2)


# 2) Verifique que las selecciones forward y backward entregan el mismo modelo -------------------
# en este problema (recuerde que esto no es siempre así). Utilice significancia 5%.

# forward


modelo = lm(largo ~ 1, data = df)
add1(modelo, ~. + edad + temp, test = "F") # Agregamos edad al tener el menor valor p y cumplir la sig 0.05


modelo = lm(largo ~ edad, data = df)
add1(modelo, ~. + temp, test = "F") # Agregamos temp al tener el menor valor p y cumplir la sig 0.05


modelo = lm(largo ~ edad + temp, data = df)
summary(modelo)


# backward


modelo_back = lm(largo ~ edad + temp, data = df)
drop1(modelo_back, test = "F") # No se elimina ningun predictor al no cumplir el ningun valor p por encima de la sig 0.05
summary(modelo_back)


# Stepwise


modelo_step = lm(largo ~ 1, data = df)
add1(modelo_step, ~. + edad + temp, test = "F") # Agregamos edad al tener el menor valor p y cumplir la sig 0.05


modelo_step = lm(largo ~ edad, data = df)
drop1(modelo_step, test = "F") # No se elimina al no tener un valor p mayor a la sig 0.05


modelo_step = lm(largo ~ edad, data = df)
add1(modelo_step, ~. + temp, test = "F") 


modelo_step = lm(largo ~ edad + temp, data = df)
drop1(modelo_step, test = "F") 


modelo_step = lm(largo ~ edad + temp, data = df)
summary(modelo_step)



# R2 ajustado


summary(modelo)
summary(modelo_back)
summary(modelo_step)


#cp de mallows


sigma2_gorro_modelo = summary(modelo)$sigma^2
e_modelo = resid(modelo)
sce_modelo = sum(e_modelo*e_modelo)
p_modelo = length(coef(modelo))
n_modelo = nrow(df)
cp_modelo = (sce_modelo/sigma2_gorro_modelo)+2*p_modelo-n_modelo #tiene que dar aprox al numero de coef


sigma2_gorro_modelo_back = summary(modelo_back)$sigma^2
e_modelo_back = resid(modelo_back)
sce_modelo_back = sum(e_modelo_back*e_modelo_back)
p_modelo_back = length(coef(modelo_back))
n_modelo_back = nrow(df)
cp_modelo_back = (sce_modelo_back/sigma2_gorro_modelo_back)+2*p_modelo_back-n_modelo_back #tiene que dar aprox al numero de coef


sigma2_gorro_modelo_step = summary(modelo_step)$sigma^2
e_modelo_step = resid(modelo_step)
sce_modelo_step = sum(e_modelo_step*e_modelo_step)
p_modelo_step = length(coef(modelo_step))
n_modelo_step = nrow(df)
cp_modelo_step = (sce_modelo_step/sigma2_gorro_modelo_step)+2*p_modelo_step-n_modelo_step


cp_modelo
cp_modelo_back
cp_modelo_step


# estadistico press

h_modelo = ls.diag(modelo)$hat
sum((e_modelo/1-h_modelo)^2) #debe ser pequeño, relativo


h_modelo_back = ls.diag(modelo_back)$hat
sum((e_modelo_back/1-h_modelo_back)^2) #debe ser pequeño, relativo


h_modelo_step = ls.diag(modelo_step)$hat
sum((e_modelo_step/1-h_modelo_step)^2)

# AIC Y BIC

AIC(modelo)
AIC(modelo_back)
AIC(modelo_step)


BIC(modelo)
BIC(modelo_back)
BIC(modelo_step)


# 3) Ajuste el modelo seleccionado. Realice un análisis de los supuestos del ----------------
# modelo: especificación de la media, homocedasticidad, normalidad, presencia de
# outliers. En caso de existir outliers, identifíquelos en un gráfico del largo de los
# peces versus su edad. 


modelo = lm(largo ~ edad + temp, data = df)
summary(modelo)

# Supuestos minímos

# Especificación de la media

residuos = resid(modelo) #residuos estandar
g7 = ggplot(df, aes(x = edad, y = residuos, color = temp)) +
  geom_point(size = 2, alpha = 0.7) +
  geom_hline(yintercept = 0, color = "red") +
  labs(
    title = "Residuos vs Edad (coloreados por tanque)",
    x = "Edad en días",
    y = "Residuos",
    color = "Tanque de agua"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold")
  )


# Homocedasticidad

r_est = ls.diag(modelo)$std.res #residuos estandar
g8 = ggplot(df, aes(x = edad, y = r_est, color = temp)) +
  geom_point(size = 2, alpha = 0.7) +
  geom_hline(yintercept = 0, color = "red") +
  labs(title = "Residuos vs Edad (coloreados por tanque)", y = "Residuos Normalizados", x = "Edad en días", color = "Tanque de agua")+
  theme_minimal()+
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold")
  )


grid.arrange(g7, g8, ncol = 2)

# Normalidad


qqnorm(r_est)
qqline(r_est)
shapiro.test(r_est) #no se rechaza h0, podemos asumir normalidad en los residuos


# Precencia de outliers


ggplot(df, aes(x = edad, y = largo))+
  geom_point(alpha = 0.6)+
  geom_smooth(method = "lm", se = F, color = "blue")+
  theme_minimal(base_size = 13)+
  labs(title = "Edad vs Largo", y = "Largo en cm", x = "Edad en días")+
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold")
  )


# 4) Realice un análisis para determinar si existen observaciones influyentes. ------------------
# ¿Existen observaciones para las que se debiese analizar su exclusión en el ajuste del
# modelo? Discuta (puede utilizar nuevos gráficos para apoyar sus observaciones).


cooks = cooks.distance(modelo)


which(cooks > 4 / (nrow(df)-length(coef(modelo))-1)) # alta influencia


umbral = 4 / (nrow(df)-length(coef(modelo))-1)


df$influyente = cooks > umbral


#plot(modelo, which = 4)  # Distancia de Cook


ggplot(df, aes(x = edad, y = largo)) +
  geom_point(aes(shape = influyente), size = 2.5, alpha = 0.8) +
  geom_smooth(method = "lm", se = FALSE) +
  scale_shape_manual(
    values = c(`FALSE` = 10, `TRUE` = 15),
    labels = c(`FALSE` = "No influyente", `TRUE` = "Influyente"),
    name = "Tipo de observación"
  ) +
  labs(
    title = "Relación entre Largo y Edad por Tanque",
    subtitle = paste0("Observaciones influyentes según Cook (umbral = ", round(umbral, 4), ")"),
    x = "Edad²",
    y = "Largo",
    color = "Tanque de agua"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    plot.subtitle = element_text(hjust = 0.5)
  )


# 5) Alternativamente, se propone ajustar un modelo cuadrático a los datos. -------------------
# Para ello, defina un nuevo predictor, edad2 = edad^2, y ajuste el modelo: largo ∼ edad +edad2+temp.


df$edad2 = df$edad^2


modelo_new = lm(largo ~ edad + edad2 + temp, data = df)
summary(modelo_new)


# 6) Realice un análisis de los supuestos del modelo: especificación de la media, -------------------
# homocedasticidad, normalidad, presencia de outliers. En caso de existir outliers,
# identifíquelos en un gráfico del largo de los peces versus su edad.

# Supuestos minímos

# Especificación de la media

residuos = resid(modelo_new) #residuos estandar
gf1 = ggplot(df, aes(x = edad, y = residuos)) +
  geom_point() +
  geom_hline(yintercept = 0, color = "red") +
  labs(title = "Residuos", y = "Residuos", x = "Edad en días")+
  theme_minimal()+
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold")
  )

gf2 = ggplot(df, aes(x = edad2, y = residuos)) +
  geom_point() +
  geom_hline(yintercept = 0, color = "red") +
  labs(title = "Residuos", y = "Residuos", x = "Edad en días (al cuadrado)")+
  theme_minimal()+
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold")
  )


grid.arrange(gf1, gf2, ncol = 2)


# Homocedasticidad

r_est = ls.diag(modelo_new)$std.res #residuos estandar

gf3 = ggplot(df, aes(x = edad, y = r_est)) +
  geom_point() +
  geom_hline(yintercept = 0, color = "red") +
  labs(title = "Residuos normalizados", y = "Residuos estandarizados", x = "Edad en días")+
  theme_minimal()+
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold")
  )

gf4 = ggplot(df, aes(x = edad2, y = r_est)) +
  geom_point() +
  geom_hline(yintercept = 0, color = "red") +
  labs(title = "Residuos normalizados", y = "Residuos estandarizados", x = "Edad en días (al cuadrado)")+
  theme_minimal()+
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold")
  )

grid.arrange(gf3, gf4, ncol = 2)

# Normalidad


qqnorm(r_est)
qqline(r_est)
shapiro.test(r_est) #no se rechaza h0, podemos asumir normalidad en los residuos


# Precencia de outliers


ggplot(df, aes(x = edad2, y = largo))+
  geom_point(alpha = 0.6)+
  geom_smooth(method = "lm", se = F, color = "blue")+
  theme_minimal(base_size = 13)+
  labs(title = "Edad cuadratica vs Largo", y = "Largo en cm", x = "Edad en días (al cuadrado)")+
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold")
  )


# 7) Realice un análisis para determinar si existen observaciones influyentes. ----------------
# ¿Existen observaciones para las que se debiese analizar su exclusión en el ajuste del
# modelo? Discuta (puede utilizar nuevos gráficos para apoyar sus observaciones).


cooks = cooks.distance(modelo_new)


which(cooks > 4 / (nrow(df)-length(coef(modelo_new))-1)) # alta influencia


umbral = 4 / (nrow(df)-length(coef(modelo_new))-1)


df$influyente = cooks > umbral


plot(modelo, which = 4)  # Distancia de Cook


ggplot(df, aes(x = edad2, y = largo)) +
  geom_point(aes(shape = influyente), size = 2.5, alpha = 0.8) +
  geom_smooth(method = "lm", se = FALSE) +
  scale_shape_manual(
    values = c(`FALSE` = 10, `TRUE` = 15),
    labels = c(`FALSE` = "No influyente", `TRUE` = "Influyente"),
    name = "Tipo de observación"
  ) +
  labs(
    title = "Relación entre Largo y Edad² por Tanque",
    subtitle = paste0("Observaciones influyentes según Cook (umbral = ", round(umbral, 4), ")"),
    x = "Edad²",
    y = "Largo",
    color = "Tanque de agua"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    plot.subtitle = element_text(hjust = 0.5)
  )


# 8) Obtenga un gráfico del largo de los peces versus su edad que: ---------------------
# • identifique con colores o símbolos la temperatura del tanque a la que corre sponde cada observación,
# • muestre las curvas ajustadas, distinguiendo la temperatura con los mismos
# colores o símbolos con que identificó las observaciones,
# • identifique la(s) observación(es) cuya exclusión debiese ser analizada.
# Extraiga de la figura dos conclusiones globales sobre el ajuste del modelo y la relación
# entre las variables.


ggplot(df, aes(x = edad2, y = largo, color = temp)) +
  geom_point(aes(shape = influyente), size = 2.5, alpha = 0.8) +
  geom_smooth(method = "lm", se = FALSE) +
  scale_shape_manual(
    values = c(`FALSE` = 10, `TRUE` = 15),
    labels = c(`FALSE` = "No influyente", `TRUE` = "Influyente"),
    name = "Tipo de observación"
  ) +
  labs(
    title = "Relación entre Largo y Edad² por Tanque",
    subtitle = paste0("Observaciones influyentes según Cook (umbral = ", round(umbral, 4), ")"),
    x = "Edad²",
    y = "Largo",
    color = "Tanque de agua"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    plot.subtitle = element_text(hjust = 0.5)
  )










