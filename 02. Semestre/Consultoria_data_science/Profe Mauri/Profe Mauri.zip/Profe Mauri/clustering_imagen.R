# Clustering de una imagen


rm(list = ls())


ruta <- "C:/Users/19990772/Desktop/Mg Data Science/Segundo semestre/Consultoria Data Sciente"


setwd(ruta)


library(png)
library(jpeg)
library(ggplot2)
library(dplyr)
library(imager)
library(scales)
library(ClusterR)
library(readxl)
library(openxlsx)


# Áreas del lago ----------------

#img <- readPNG("Imagen recortada_v2.png")
img <- readJPEG("Lago rql 04-01-2019_v3.jpg")


imgDm <- dim(img)


imgRGB <- data.frame(
  x = rep(1:imgDm[2], each = imgDm[1]),
  y = rep(imgDm[1]:1, imgDm[2]),
  R = as.vector(img[,,1]),
  G = as.vector(img[,,2]),
  B = as.vector(img[,,3])
)


plotTheme <- function(){
  theme(
    panel.background = element_rect(
      size = 3,
      colour = "black",
      fill= "white"),
    axis.ticks = element_line(
      size = 2),
    panel.grid.major = element_line(
      colour = "gray80",
      linetype = "dashed"),
    axis.title.x = element_text(
      size = rel(1.2),
      face = "bold"),
    axis.title.y = element_text(
      size = rel(1.2),
      face = "bold"),
    plot.title = element_text(
      size = 20,
      face = "bold",
      vjust = 1.5)
  )
}

# Se demora unos segundos pero lo compila
ggplot(data= imgRGB, aes(x = x, y = y)) +
  geom_point(colour = rgb(imgRGB[c("R","G","B")]))+
  labs(title= "Imagen original")+
  xlab("x")+
  ylab("y")+
  plotTheme()


# Ahora el clustering

set.seed(1234)

kClusters <- 12 #8 el mejor por ahora
kMeans<- kmeans(imgRGB[, c("R", "G", "B")], centers = kClusters)
kColours <- rgb(kMeans$centers[kMeans$cluster, ])
imgRGB$cluster <- kMeans$cluster


# Binarizar

# Escoge el cluster que quieres resaltar en negro
cluster_objetivo <- 6

# Creamos una variable binaria: negro (0) si pertenece al cluster, blanco (1) si no
imgRGB$mask <- ifelse(imgRGB$cluster == cluster_objetivo, 1, 0)

# Ahora generamos colores RGB (negro/blanco)
mask_colours <- rgb(imgRGB$mask, imgRGB$mask, imgRGB$mask)

# Graficamos la "imagen en blanco y negro"
plot(imgRGB$x, imgRGB$y, col = mask_colours, pch = 15, cex = 0.5, asp = 1,
     xlab = "", ylab = "", axes = FALSE, main = "")


# 1) Resumen por cluster: tamaño, RGB medio, luminancia y HSV
centros <- imgRGB %>%
  group_by(cluster) %>%
  summarise(
    Rm = mean(R),
    Gm = mean(G),
    Bm = mean(B),
    n_pix = n(),
    .groups = "drop"
  ) %>%
  mutate(
    pct = n_pix / nrow(imgRGB) * 100,
    en_decimales = n_pix / nrow(imgRGB),
    superficie_del_cluster = 165.63*en_decimales,
    luminancia = 0.2126*Rm + 0.7152*Gm + 0.0722*Bm
  )


hsv_mat <- t(grDevices::rgb2hsv(centros$Rm, centros$Gm, centros$Bm))
centros <- cbind(centros, as.data.frame(hsv_mat))
names(centros)[ncol(centros)-2:0] <- c("H","S","V") # por claridad

# Mostrar ordenado por luminancia (más oscuro arriba)
print(centros %>% arrange(luminancia))


ggplot(data = imgRGB, aes(x = x, y = y)) + 
  geom_point(colour = kColours) + 
  labs(title = paste("K-means Clustering de", kClusters, "Colores"))+
  xlab("x")+
  ylab("y")+
  plotTheme()


# 2) Visualiza la distribución de clusters (rápido)
pal <- rgb(centros$Rm, centros$Gm, centros$Bm)

ggplot(imgRGB, aes(x = x, y = y, fill = factor(cluster))) +
  geom_raster() +
  scale_fill_manual(values = pal) +
  coord_fixed() +
  labs(title = "Mapa de clusters (visual)", fill = "cluster") +
  theme_minimal()

# Ya con el grafico y el data.frame centros tenemos el numero del cluster y su % respectivo

# Cada imagen son 165.63 km cuadrados, el lago debe estar cerca de los 31km2, el porcentaje debe estar cerca del 18%

# Imagen 13-02-2018_v2 tiene un 19.269041% de agua el lago rql con 12 clusters = 31.91531

# Imagen 30-12-2018_v2 tiene un 20.322408% de agua el lago rql con 3 clusters = 33.660005

# Imagen 04-01-2019_v2 tiene un 18.341001% de agua el lago rql con 10 clusters = 30.378200

# Imagen 05-11-2019_v2 tiene un 19.466734% de agua el lago rql con 5 clusters = 32.242752

# Imagen 08-02-2020_v2 tiene un 19.922961% de agua el lago rql con 3 clusters = 32.99840

# Imagen 09-12-2020_v2 tiene un 20.4789026% de agua el lago rql con 3 clusters = 33.919206

# Imagen 18-01-2021_v2 tiene un 18.861882% de agua el lago rql con 9 clusters = 31.240935

# Imagen 24-12-2021_v2 tiene un 19.3672159% de agua el lago rql con 11 clusters = 32.0779198

# Imagen 17-02-2022_v2 tiene un 18.248762% de agua el lago rql con 9 clusters = 30.225424 

# Imagen 24-12-2022_v2 tiene un 19.598389% de agua el lago rql con 9 clusters = 32.460811

# Imagen 27-02-2023 tiene un 18.971584% de agua el lago rql con 13 clusters = 31.422634

# Imagen 24-12-2023 tiene un 18.9671167% de agua el lago rql con 9 clusters = 31.4152355

# Imagen 21-07-2024_v2 tiene un 18.153479% de agua el lago rql con 9 clusters = 30.067608

# Imagen 23-12-2024 tiene un 18.153479% de agua el lago rql con 9 clusters = 30.067608



# Aqui aplicamos el Mini Batch kMeans cuando sepa que hace ajsbdhjsabd



# EDA -------------------
temperaturas_minima <- tibble(read_excel("Archivos excels/Temperaturas minima.xlsx"))


temperaturas_minima <- temperaturas_minima %>% filter(agno > 2017 & agno < 2025)


temperaturas_minima <- temperaturas_minima %>% group_by(agno, mes) %>% summarise(media = mean(valor))


temperaturas_maxima <- tibble(read_excel("Archivos excels/Temperaturas maxima.xlsx"))


temperaturas_maxima <- temperaturas_maxima %>% filter(agno > 2017 & agno < 2025)


temperaturas_maxima <- temperaturas_maxima %>% group_by(agno, mes) %>% summarise(media = mean(valor))


temperaturas_media <- tibble(read_excel("Archivos excels/Temperaturas medias.xlsx"))


temperaturas_media <- temperaturas_media %>% filter(agno > 2017 & agno < 2025)


temperaturas_media <- temperaturas_media %>% group_by(agno, mes) %>% summarise(media = mean(valor))


lluvia <- tibble(read_excel("Archivos excels/Precipitaciones.xlsx"))


lluvia <- lluvia %>% filter(agno > 2017 & agno < 2025)


lluvia <- lluvia %>% group_by(agno, mes) %>% summarise(suma = sum(valor))


areas <- tibble(read_excel("áreas lago.xlsx"))


# Grafico de áreas ----------

prom_areas_anio <- areas %>% group_by(Año) %>% summarise(Media = mean(Área))


ggplot(prom_areas_anio, aes(x = Año, y = Media))+
  geom_line(color = "steelblue", size = 1.5) +              # línea
  geom_point(color = "darkred", size = 4) +               # puntos grandes
  scale_y_continuous(limits = c(30.6, 33.6),
                     breaks = seq(30.6, 33.6, 0.2)) +         # límites del eje Y
  scale_x_continuous(breaks = prom_areas_anio$Año) +      # Mostrar todos los años
  theme_minimal(base_size = 14) +                         # estilo limpio
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),  # título centrado y negrita
    axis.text = element_text(face = "bold"),                # valores ejes en negrita
    axis.title = element_text(face = "bold")                # nombres ejes en negrita
  ) +
  labs(
    title = "Evolución de Áreas en km2",
    x = "Año",
    y = "Áreas (km2)"
  )


# Grafico de lluvia ----------
lluvia_año <- lluvia %>% group_by(agno) %>% summarise(suma = sum(suma))


lluvia_año <- lluvia_año %>% mutate(
  max_lluvia = suma == max(suma)
)

# Agregar el valor arriba en cada barra (y asi quitar el eje y?)
ggplot(lluvia_año, aes(x = factor(agno), y = suma, fill = max_lluvia)) +
  geom_col() +
  geom_text(aes(label = suma), vjust = -0.5, fontface = "bold") +
  scale_fill_manual(values = c("FALSE" = "steelblue", "TRUE" = "darkred")) + # color distinto para el máximo
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    axis.text = element_text(face = "bold"),
    axis.title = element_text(face = "bold"),
    legend.position = "none"   # sacamos la leyenda (ya se entiende)
  ) +
  labs(
    title = "Precipitaciones en mm por año",
    x = "Año",
    y = "Precipitaciones (mm)"
  )


# Grafico de temperaturas minimas ----------
prom_temp_min <- temperaturas_minima %>% group_by(agno) %>% summarise(Media = mean(media))

ggplot(prom_temp_min, aes(x = agno, y = Media))+
  geom_line(color = "steelblue", size = 1.5) +              # línea
  geom_point(color = "darkred", size = 4) +               # puntos grandes
  scale_y_continuous(limits = c(round(min(prom_temp_min$Media),1)-0.1, max(prom_temp_min$Media)),
                     breaks = seq(round(min(prom_temp_min$Media))-0.2, max(prom_temp_min$Media)+0.1, 0.2)) +         # límites del eje Y
  scale_x_continuous(breaks = prom_temp_min$agno) +      # Mostrar todos los años
  theme_minimal(base_size = 14) +                         # estilo limpio
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),  # título centrado y negrita
    axis.text = element_text(face = "bold"),                # valores ejes en negrita
    axis.title = element_text(face = "bold")                # nombres ejes en negrita
  ) +
  labs(
    title = "Evolución de temperatura mínima",
    x = "Año",
    y = "Temperatura (en Celcius)"
  )


# Grafico de temperaturas medias ----------
prom_temp_media <- temperaturas_media %>% group_by(agno) %>% summarise(Media = mean(media))

ggplot(prom_temp_media, aes(x = agno, y = Media))+
  geom_line(color = "steelblue", size = 1.5) +              # línea
  geom_point(color = "darkred", size = 4) +               # puntos grandes
  scale_y_continuous(limits = c(round(min(prom_temp_media$Media),1)-0.1, max(prom_temp_media$Media)),
                     breaks = seq(round(min(prom_temp_media$Media))-0.2, max(prom_temp_media$Media)+0.1, 0.2)) +         # límites del eje Y
  scale_x_continuous(breaks = prom_temp_media$agno) +      # Mostrar todos los años
  theme_minimal(base_size = 14) +                         # estilo limpio
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),  # título centrado y negrita
    axis.text = element_text(face = "bold"),                # valores ejes en negrita
    axis.title = element_text(face = "bold")                # nombres ejes en negrita
  ) +
  labs(
    title = "Evolución de temperatura medias anual",
    x = "Año",
    y = "Temperatura (en Celcius)"
  )


# Grafico de temperaturas maximas ----------
prom_temp_max <- temperaturas_maxima %>% group_by(agno) %>% summarise(Media = mean(media))

ggplot(prom_temp_max, aes(x = agno, y = Media))+
  geom_line(color = "steelblue", size = 1.5) +              # línea
  geom_point(color = "darkred", size = 4) +               # puntos grandes
  scale_y_continuous(limits = c(round(min(prom_temp_max$Media),1)-0.1, max(prom_temp_max$Media)),
                     breaks = seq(round(min(prom_temp_max$Media))-0.2, max(prom_temp_max$Media)+0.1, 0.2)) +         # límites del eje Y
  scale_x_continuous(breaks = prom_temp_max$agno) +      # Mostrar todos los años
  theme_minimal(base_size = 14) +                         # estilo limpio
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),  # título centrado y negrita
    axis.text = element_text(face = "bold"),                # valores ejes en negrita
    axis.title = element_text(face = "bold")                # nombres ejes en negrita
  ) +
  labs(
    title = "Evolución de temperatura máximas",
    x = "Año",
    y = "Temperatura (en Celcius)"
  )

# Matriz de correlaciones -------------


data_unida_por_año <- cbind(prom_areas_anio, prom_temp_min$Media, prom_temp_media$Media, prom_temp_max$Media, lluvia_año$suma)


data_unida <- areas[,c("Año", "Mes", "Área")]


data_unida <- cbind(data_unida, lluvia$suma)


data_unida <- cbind(data_unida, temperaturas_minima$media, temperaturas_media$media, temperaturas_maxima$media)


names(data_unida)[4:ncol(data_unida)] <- c("Lluvia", "Temp_Minima", "Temp_Media", "Temp_Maxima")


data_unida <- data_unida[,-2]


#columnas <- c("Año", "Área", "Lluvia", "Temp_Minima", "Temp_Media", "Temp_Maxima")


corr_matrix <- cor(data_unida)


library(ggpubr)


p_matrix <- cor_pmat(data_unida)


library(ggcorrplot)


ggcorrplot(corr_matrix, hc.order = TRUE, type = "lower",
           lab = TRUE, lab_size = 3, 
           colors = c("red", "white", "blue"),
           title = "Matriz de Correlación",
           ggtheme = theme_minimal())


ggcorrplot(corr_matrix, 
           hc.order = TRUE, type = "lower",
           lab = TRUE, lab_size = 3,
           p.mat = p_matrix, sig.level = 0.05,
           insig = "blank",
           colors = c("red", "white", "blue"),
           title = "Matriz de Correlación con Significancia",
           ggtheme = theme_minimal())


# Aqui los graficos de dispersión --------------

# área vs lluvia
ggplot(data_unida, aes(x = Lluvia, y = Área)) +
  geom_point(color = "steelblue", size = 3, alpha = 0.7) +    # puntos bonitos
  geom_smooth(method = "lm", color = "darkred", se = F) +  # línea de regresión con banda de confianza
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    axis.text = element_text(face = "bold"),
    axis.title = element_text(face = "bold")
  ) +
  labs(
    title = "Relación Área y Lluvia",
    x = "Lluvia (mm)",
    y = "Área (km2)"
  )


# Área vs temp_minima
ggplot(data_unida, aes(x = Temp_Minima, y = Área)) +
  geom_point(color = "steelblue", size = 3, alpha = 0.7) +    # puntos bonitos
  geom_smooth(method = "lm", color = "darkred", se = F) +  # línea de regresión con banda de confianza
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    axis.text = element_text(face = "bold"),
    axis.title = element_text(face = "bold")
  ) +
  labs(
    title = "Relación Área y Temperatura mínima",
    x = "Temperatura (Celcius)",
    y = "Área (km2)"
  )


# Área vs temp_media
ggplot(data_unida, aes(x = Temp_Media, y = Área)) +
  geom_point(color = "steelblue", size = 3, alpha = 0.7) +    # puntos bonitos
  geom_smooth(method = "lm", color = "darkred", se = F) +  # línea de regresión con banda de confianza
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    axis.text = element_text(face = "bold"),
    axis.title = element_text(face = "bold")
  ) +
  labs(
    title = "Relación Área y Temperatura media",
    x = "Temperatura (Celcius)",
    y = "Área (km2)"
  )


# Área vs temp_maxima
ggplot(data_unida, aes(x = Temp_Maxima, y = Área)) +
  geom_point(color = "steelblue", size = 3, alpha = 0.7) +    # puntos bonitos
  geom_smooth(method = "lm", color = "darkred", se = F) +  # línea de regresión con banda de confianza
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    axis.text = element_text(face = "bold"),
    axis.title = element_text(face = "bold")
  ) +
  labs(
    title = "Relación Área y Temperatura máxima",
    x = "Temperatura (Celcius)",
    y = "Área (km2)"
  )


# Lluvia vs temp_minima
ggplot(data_unida, aes(x = Lluvia, y = Temp_Minima)) +
  geom_point(color = "steelblue", size = 3, alpha = 0.7) +    # puntos bonitos
  geom_smooth(method = "lm", color = "darkred", se = F) +  # línea de regresión con banda de confianza
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    axis.text = element_text(face = "bold"),
    axis.title = element_text(face = "bold")
  ) +
  labs(
    title = "Relación Precipitaciones y Temperatura miníma",
    x = "Precipitaciones (mm)",
    y = "Temperatura (Celcius)"
  )


# Lluvia vs temp_media
ggplot(data_unida, aes(x = Lluvia, y = Temp_Media)) +
  geom_point(color = "steelblue", size = 3, alpha = 0.7) +    # puntos bonitos
  geom_smooth(method = "lm", color = "darkred", se = F) +  # línea de regresión con banda de confianza
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    axis.text = element_text(face = "bold"),
    axis.title = element_text(face = "bold")
  ) +
  labs(
    title = "Relación Precipitaciones y Temperatura media",
    x = "Precipitaciones (mm)",
    y = "Temperatura (Celcius)"
  )


# Lluvia vs temp_maxima
ggplot(data_unida, aes(x = Lluvia, y = Temp_Maxima)) +
  geom_point(color = "steelblue", size = 3, alpha = 0.7) +    # puntos bonitos
  geom_smooth(method = "lm", color = "darkred", se = F) +  # línea de regresión con banda de confianza
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    axis.text = element_text(face = "bold"),
    axis.title = element_text(face = "bold")
  ) +
  labs(
    title = "Relación Precipitaciones y Temperatura máxima",
    x = "Precipitaciones (mm)",
    y = "Temperatura (Celcius)"
  )


# Temp_minima vs temp_máxima
ggplot(data_unida, aes(x = Temp_Minima, y = Temp_Maxima)) +
  geom_point(color = "steelblue", size = 3, alpha = 0.7) +    # puntos bonitos
  geom_smooth(method = "lm", color = "darkred", se = F) +  # línea de regresión con banda de confianza
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    axis.text = element_text(face = "bold"),
    axis.title = element_text(face = "bold")
  ) +
  labs(
    title = "Relación Temperatura miníma y Temperatura máxima",
    x = "Temperatura (Celcius)",
    y = "Temperatura (Celcius)"
  )

# Colocar solo un caso de lluvia vs temperatura y temperatura vs temperatura, ya en la matriz se nota














# Modelo de predicción -----------


names(lluvia)[3] <- c("lluvia")


names(temperaturas_minima)[3] <- c("temp_minima")


names(temperaturas_media)[3] <- "temp_media"


names(temperaturas_maxima)[3] <- "temp_maxima"


data <- cbind(areas, temperaturas_minima$temp_minima, temperaturas_media$temp_media, temperaturas_maxima$temp_maxima, lluvia$lluvia)


names(data)[5:8] <- c("temp_minima", "temp_media", "temp_maxima", "lluvia")


df <- data[,4:8]


# Regresión OLS


modelo_ols <- lm(Área ~ temp_minima + temp_media + temp_maxima + lluvia, data = df)
summary(modelo_ols)


library(glmnet)


x <- as.matrix(df[,2:5])
y <- df$Área


modelo_lasso <- cv.glmnet(x, y, alpha = 1)
modelo_ridge <- cv.glmnet(x, y, alpha = 0)



library(caret)        # para validación cruzada y comparación
library(glmnet)       # para Lasso/Ridge
library(randomForest) # Random Forest
library(mgcv)         # GAM

# Supongamos que tu dataset se llama "datos"
# head(datos)

# Definir fórmula
formula <- Área ~ temp_minima + temp_media + temp_maxima + lluvia


# Configuración de validación

set.seed(123)
control <- trainControl(method = "LOOCV")  # 10-fold cross validation


# 1. Regresión lineal (OLS)

modelo_lm <- train(formula, data = df,
                   method = "lm",
                   trControl = control)


# 2. GAM (modelos aditivos)

modelo_gam <- train(formula, data = df,
                    method = "gam",
                    trControl = control)


# 3. Lasso y Ridge (glmnet)

modelo_glmnet <- train(
  formula,
  data = df,
  method = "glmnet",
  trControl = control,
  tuneGrid = expand.grid(
    alpha = 0,                    # Ridge
    lambda = seq(0.0001, 1, length = 50)  # penalización
  )
) # busca mejores lambdas, probar más opciones, LOO leave one out, validación cruzada de más observaciones
# laso fuerza algunos 0, ridge no fuerza pero deja 0, asi o al revez

# 4. Random Forest

modelo_rf <- train(formula, data = df,
                   method = "rf",
                   trControl = control,
                   tuneLength = 5)


# Comparación de resultados

comparacion_loo <- data.frame(
  Modelo = c("OLS", "GAM", "Ridge"),
  RMSE = c(
    modelo_lm$results$RMSE[which.min(modelo_lm$results$RMSE)],
    modelo_gam$results$RMSE[which.min(modelo_gam$results$RMSE)],
    modelo_glmnet$results$RMSE[which.min(modelo_glmnet$results$RMSE)]
  ),
  R2 = c(
    modelo_lm$results$Rsquared[which.min(modelo_lm$results$RMSE)],
    modelo_gam$results$Rsquared[which.min(modelo_gam$results$RMSE)],
    modelo_glmnet$results$Rsquared[which.min(modelo_glmnet$results$RMSE)]
  ),
  MAE = c(
    modelo_lm$results$MAE[which.min(modelo_lm$results$RMSE)],
    modelo_gam$results$MAE[which.min(modelo_gam$results$RMSE)],
    modelo_glmnet$results$MAE[which.min(modelo_glmnet$results$RMSE)]
  )
)

comparacion_loo


control <- trainControl(
  method = "LOOCV",
  savePredictions = "final"
)


# Extraer predicciones y errores
pred_lm <- modelo_lm$pred
pred_gam <- modelo_gam$pred
pred_ridge <- modelo_glmnet$pred

# Calcular errores absolutos y cuadráticos
errores_lm <- data.frame(
  Modelo = "OLS",
  Abs = abs(pred_lm$obs - pred_lm$pred),
  Cuad = (pred_lm$obs - pred_lm$pred)^2
)

errores_gam <- data.frame(
  Modelo = "GAM",
  Abs = abs(pred_gam$obs - pred_gam$pred),
  Cuad = (pred_gam$obs - pred_gam$pred)^2
)

errores_ridge <- data.frame(
  Modelo = "Ridge",
  Abs = abs(pred_ridge$obs - pred_ridge$pred),
  Cuad = (pred_ridge$obs - pred_ridge$pred)^2
)



errores_total <- rbind(errores_lm, errores_gam, errores_ridge)


library(tidyr)

errores_long <- errores_total %>%
  pivot_longer(cols = c("Abs", "Cuad"),
               names_to = "Tipo",
               values_to = "Error")


ggplot(errores_long, aes(x = Modelo, y = Error, fill = Modelo)) +
  geom_boxplot(alpha = 0.7, outlier.alpha = 0.3) +
  facet_wrap(~Tipo, scales = "free_y",
             labeller = as_labeller(c(Abs = "Error absoluto", Cuad = "Error cuadrático"))) +
  labs(title = "Distribución de errores por modelo (LOOCV)",
       y = "Valor del error", x = "Modelo") +
  theme_minimal(base_size = 13) +
  theme(legend.position = "none",
        strip.text = element_text(face = "bold"))


# Predicción (Ridge) -----------


library(glmnet)

formula <- Área ~ temp_minima + temp_media + temp_maxima + lluvia


# Configuración de validación

set.seed(123)
control <- trainControl(method = "LOOCV")  # 10-fold cross validation

# Lasso y Ridge (glmnet)

modelo_glmnet <- train(
  formula,
  data = df,
  method = "glmnet",
  trControl = control,
  tuneGrid = expand.grid(
    alpha = 0,                    # Ridge
    lambda = seq(0.0001, 1, length = 50)  # penalización
  )
) # busca mejores lambdas, probar más opciones, LOO leave one out, validación cruzada de más observaciones
# laso fuerza algunos 0, ridge no fuerza pero deja 0, asi o al revez



errores <- areas$Área - modelo_glmnet$pred


sd_error <- sd(errores$pred)


pred_temp_minima <- tibble(read_excel("Archivos excels/Simulaciones_temperaturas_minimas.xlsx"))


pred_temp_minima <- pred_temp_minima[-1,]


names(pred_temp_minima) <- tolower(pred_temp_minima[1,])


pred_temp_minima <- pred_temp_minima[-1,]


pred_temp_minima$datetime <- as.POSIXct(as.numeric(pred_temp_minima$datetime)*86400,
                                origin = "1899-12-31", tz = "America/Santiago")


pred_temp_minima <- pred_temp_minima %>% filter(datetime > as.Date("2024-12-31"))


columnas <- c("datetime", "promedio de escenario: rcp26", "promedio de escenario: rcp85")


simu_temp_minima <- pred_temp_minima[,columnas]


pred_temp_maxima <- tibble(read_excel("Archivos excels/Simulaciones_temperaturas_maximas.xlsx"))


pred_temp_maxima <- pred_temp_maxima[-1,]


names(pred_temp_maxima) <- tolower(pred_temp_maxima[1,])


pred_temp_maxima <- pred_temp_maxima[-1,]


pred_temp_maxima$datetime <- as.POSIXct(as.numeric(pred_temp_maxima$datetime)*86400,
                                        origin = "1899-12-31", tz = "America/Santiago")


columnas <- c("datetime", "promedio de escenario: rcp26", "promedio de escenario: rcp85")


simu_temp_maxima <- pred_temp_maxima[,columnas]


simu_temp_maxima <- simu_temp_maxima %>% filter(datetime > as.Date("2024-12-31"))


pred_temp_medias <- tibble(read_excel("Archivos excels/Simulaciones_temperaturas.xlsx"))


pred_temp_medias <- pred_temp_medias[-1,]


names(pred_temp_medias) <- tolower(pred_temp_medias[1,])


pred_temp_medias <- pred_temp_medias[-1,]


pred_temp_medias$datetime <- as.POSIXct(as.numeric(pred_temp_medias$datetime)*86400,
                                        origin = "1899-12-31", tz = "America/Santiago")


columnas <- c("datetime", "promedio de escenario: rcp26", "promedio de escenario: rcp85")


simu_temp_medias <- pred_temp_medias[,columnas]


simu_temp_medias <- simu_temp_medias %>% filter(datetime > as.Date("2024-12-31"))


pred_lluvia <- tibble(read_excel("Archivos excels/Simulaciones_lluvia.xlsx"))


pred_lluvia <- pred_lluvia[-1,]


names(pred_lluvia) <- tolower(pred_lluvia[1,])


pred_lluvia <- pred_lluvia[-1,]


pred_lluvia$datetime <- as.POSIXct(as.numeric(pred_lluvia$datetime)*86400,
                                        origin = "1899-12-31", tz = "America/Santiago")


columnas <- c("datetime", "promedio de escenario: rcp26", "promedio de escenario: rcp85")


simu_lluvia <- pred_lluvia[,columnas]


simu_lluvia <- simu_lluvia %>% filter(datetime > as.Date("2024-12-31"))


rcp26 <- as.data.frame(cbind(simu_lluvia$`promedio de escenario: rcp26`, simu_temp_maxima$`promedio de escenario: rcp26`,
                             simu_temp_medias$`promedio de escenario: rcp26`, simu_temp_minima$`promedio de escenario: rcp26`))


rcp26[] <- lapply(rcp26, function(x) as.numeric(as.character(x)))
str(rcp26)


names(rcp26) <- c("lluvia", "temp_maxima", "temp_media", "temp_minima")


predicciones_rcp26 <- predict(modelo_glmnet, newdata = rcp26)


n <- nrow(rcp26)


fechas <- seq(from = as.Date("2025-01-01"), by = "month", length.out = n)


rcp26$area_simulada <- predicciones_rcp26


rcp26$fecha <- fechas


hist(rcp26$area_simulada)
summary(rcp26$area_simulada)
plot(rcp26$fecha, rcp26$area_simulada)

library(openxlsx)
write.xlsx(rcp26, "simulaciones_rcp25.xlsx")


rcp85 <- as.data.frame(cbind(simu_lluvia$`promedio de escenario: rcp85`, simu_temp_maxima$`promedio de escenario: rcp85`,
                             simu_temp_medias$`promedio de escenario: rcp85`, simu_temp_minima$`promedio de escenario: rcp85`))


names(rcp85) <- c("lluvia", "temp_maxima", "temp_media", "temp_minima")


rcp85[] <- lapply(rcp85, function(x) as.numeric(as.character(x)))
str(rcp85)


predicciones_rcp85 <- predict(modelo_glmnet, newdata = rcp85)


rcp85$area_simulada <- predicciones_rcp85


rcp85$fecha <- fechas


hist(rcp85$area_simulada)
summary(rcp85$area_simulada)

write.xlsx(rcp85, "simulaciones_rcp85.xlsx")


# Codigo no usado (obrigado deus!) -------

cols_rcp26 <- grep("rcp26", names(pred_temp_minima), value = TRUE)
cols_rcp26
sapply(pred_temp_minima[, cols_rcp26], class)


pred_temp_minima[, cols_rcp26] <- lapply(pred_temp_minima[, cols_rcp26], function(x) as.numeric(as.character(x)))


pred_temp_minima <- pred_temp_minima %>% mutate(promedio_RCP26 = rowMeans(select(., matches("rcp26")), na.rm = T))


cols_rcp85 <- grep("rcp85", names(pred_temp_minima), value = TRUE)
cols_rcp85
sapply(pred_temp_minima[, cols_rcp85], class)


pred_temp_minima[, cols_rcp85] <- lapply(pred_temp_minima[, cols_rcp85], function(x) as.numeric(as.character(x)))


pred_temp_minima <- pred_temp_minima %>% mutate(promedio_RCP85 = rowMeans(select(., matches("rcp85")), na.rm = T))


simu_temp_minima <- pred_temp_minima[,1]


simu_temp_minima <- cbind(simu_temp_minima, pred_temp_minima$promedio_RCP26, pred_temp_minima$promedio_RCP85)








# Trabajo de simulaciones --------


rcp25 <- tibble(read_excel("simulaciones_rcp25.xlsx"))


rcp25$año <- format(rcp25$fecha, "%Y")


rcp25$mes <- format(rcp25$fecha, "%m")


rcp25$ic_lower <- rcp25$area_simulada - 1.96 * sd_error


rcp25$ic_upper <- rcp25$area_simulada + 1.96 * sd_error


write.xlsx(rcp25, "simulaciones_rcp25.xlsx")


rcp25 <- rcp25 %>% group_by(año) %>% summarise(prom_area = mean(area_simulada))


plot(rcp25$año, rcp25$prom_area)


rcp85 <- tibble(read_excel("simulaciones_rcp85.xlsx"))


rcp85$año <- format(rcp85$fecha, "%Y")


rcp85$mes <- format(rcp85$fecha, "%m")


rcp85$ic_lower <- rcp85$area_simulada - 1.96 * sd_error


rcp85$ic_upper <- rcp85$area_simulada + 1.96 * sd_error


write.xlsx(rcp85, "simulaciones_rcp85.xlsx")


rcp85 <- rcp85 %>% group_by(año) %>% summarise(prom_area = mean(area_simulada))


plot(rcp85$año, rcp85$prom_area)


# Trabajo de simulaciones final (espero) ---------


rcp25 <- tibble(read_excel("simulaciones_rcp25.xlsx"))


rcp25 <- rcp25 %>% mutate(
  ic_lower = area_simulada - 1.96 * 0.1 * area_simulada,
  ic_upper = area_simulada + 1.96 * 0.1 * area_simulada
)


rcp25 <- rcp25 %>% group_by(año) %>% summarise(prediccion = mean(area_simulada), ic_lower = mean(ic_lower), ic_upper = mean(ic_upper))


rcp85 <- tibble(read_excel("simulaciones_rcp85.xlsx"))


rcp85 <- rcp85 %>% mutate(
  ic_lower = area_simulada - 1.96 * 0.1 * area_simulada,
  ic_upper = area_simulada + 1.96 * 0.1 * area_simulada
)


rcp85 <- rcp85 %>% group_by(año) %>% summarise(prediccion = mean(area_simulada), ic_lower = mean(ic_lower), ic_upper = mean(ic_upper))


areas <- tibble(read_excel("áreas lago.xlsx"))


areas <- areas %>% group_by(Año) %>% summarise(prom_area = mean(Área))


areas$modelo <- "Histórico"


names(areas) <- c("año", "prediccion")


names(areas)[3] <- "modelo"


areas$ic_lower <- NA


areas$ic_upper <- NA


rcp25$modelo <- "RCP 2.6"


rcp85$modelo <- "RCP 8.5"


# Unimos todo


rcp25$año <- as.numeric(rcp25$año)


rcp85$año <- as.numeric(rcp85$año)


df_plot <- bind_rows(areas, rcp25, rcp85)



library(ggplot2)

ggplot(df_plot, aes(x = año, y = prediccion, color = modelo)) +
  geom_line(size = 2) +
  geom_ribbon(aes(ymin = ic_lower, ymax = ic_upper, fill = modelo),
              alpha = 0.2, color = NA) +
  theme_minimal() +
  labs(title = "Evolución del área observada y simulada",
       y = "Área", x = "Año",
       caption = "Incluye intervalos de confianza del 95% para simulaciones") +
  scale_color_manual(values = c("black", "blue", "red")) +
  scale_fill_manual(values = c("grey60", "blue", "red")) +
  coord_cartesian(ylim = c(25, 38))

# NOP
ggplot(df_plot, aes(x = año, y = prediccion, color = modelo)) +
  geom_line(size = 2) + 
  theme_minimal()+
  labs(title = "Evolución del área observada y simulada",
       y = "Área", x = "Año")+
  scale_color_manual(values = c("black", "blue", "red")) +
  scale_fill_manual(values = c("grey60", "blue", "red")) +
  coord_cartesian(ylim = c(30, 34))




# Filtramos solo los modelos simulados
df_pred <- df_plot %>% 
  filter(modelo != "Histórico")

# Graficamos
ggplot(df_pred, aes(x = año, y = prediccion, color = modelo)) +
  geom_line(size = 1.2) +
  geom_ribbon(aes(ymin = ic_lower, ymax = ic_upper, fill = modelo),
              alpha = 0.2, color = NA) +
  theme_minimal(base_size = 14) +
  labs(title = "Predicciones de área bajo diferentes escenarios",
       subtitle = "Con intervalo de confianza del 95%",
       y = "Área (unidades²)", x = "Año") +
  scale_color_manual(values = c("blue", "red")) +
  scale_fill_manual(values = c("blue", "red")) +
  coord_cartesian(ylim = c(20, 40)) +
  theme(
    legend.position = "top",
    legend.title = element_blank()
  )

ggplot(df_pred, aes(x = año, y = prediccion, color = modelo)) +
  geom_line(size = 1.2) +
  theme_minimal() +
  labs(title = "Predicciones de área bajo diferentes escenarios",
       y = "Área (unidades²)", x = "Año")+
  scale_color_manual(values = c("blue", "red")) +
  scale_fill_manual(values = c("blue", "red")) +
  theme(
    legend.position = "top",
    legend.title = element_blank()
  )
















