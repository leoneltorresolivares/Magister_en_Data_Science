rm(list = ls())

library(dbscan)


data = matrix(c(
  0,0,   
  0,1,   
  1,0,   
  5,5,   
  5,6    
), ncol = 2, byrow = TRUE)

rownames(data) = c("A","B","C","D","E")


dist_mat = dist(data, method = "manhattan") # por simplicidad de calculos que lo hice a mano
as.matrix(dist_mat)


# DBSCAN


res_db = dbscan(dist_mat, eps = 2, minPts = 2)
res_db$cluster


plot(data, col = res_db$cluster + 1, pch = 19, cex = 2)
text(data, labels = rownames(data), pos = 3)


# HDBSCAN
res = hdbscan(data, minPts = 2)
res


# Arbol jerarquico (no lo entiendo)
plot(res)


# Cluster asignados
res$cluster


res$membership_prob


plot(data, col = res$cluster + 1, pch = 19, cex = 2)
text(data, labels = rownames(data), pos = 3)


















